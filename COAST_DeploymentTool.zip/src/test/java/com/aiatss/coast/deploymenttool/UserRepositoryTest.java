package com.aiatss.coast.deploymenttool;

import com.aiatss.coast.deploymenttool.bean.ldap.LdapUser;
import com.aiatss.coast.deploymenttool.domain.service.JobService;
import com.aiatss.coast.deploymenttool.domain.service.LogService;
import com.aiatss.coast.deploymenttool.domain.service.SqlExecuteService;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobDefinition;
import com.aiatss.coast.deploymenttool.infrastructure.repository.JobMasterRepository;
import com.aiatss.coast.deploymenttool.infrastructure.repository.PermissionRepository;
import com.aiatss.coast.deploymenttool.infrastructure.repository.SqlSequenceRepository;
import com.aiatss.coast.deploymenttool.infrastructure.repository.UserRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-*.xml" })
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private SqlSequenceRepository sqlSequenceRepository;

    @Autowired
    private SqlExecuteService sqlExecuteService;

    @Autowired
    private LogService logService;

    @Autowired
    private JobService jobService;

    @Autowired
    private JobMasterRepository jobMasterRepository;

    @Autowired
    private LdapTemplate ldapTemplate;

    @Test
    public void should_run() {
        JobDefinition one = jobMasterRepository.findOne(1);
        LdapQuery ldapQuery = query().where("displayName").is("Luo, Cherry-YJ");
        LdapUser dept = ldapTemplate.findOne(ldapQuery, LdapUser.class);
        Assert.assertEquals(dept.getGivenName(), "Lambert");

//        SqlExecute ex = sqlExecuteService.findById(1);
//        List<File> files = sqlExecuteService.getFilesBySequences(ex);
//        System.out.println(files);
    }
}

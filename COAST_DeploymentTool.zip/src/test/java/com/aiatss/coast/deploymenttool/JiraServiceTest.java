package com.aiatss.coast.deploymenttool;

import java.io.File;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aiatss.coast.deploymenttool.domain.service.JiraRestfulUriService;
import com.aiatss.coast.deploymenttool.infrastructure.repository.ConfigRepository;
import com.aiatss.coast.deploymenttool.infrastructure.repository.JiraRestfulUriRepository;
import com.aiatss.coast.deploymenttool.infrastructure.repository.JobParamRepository;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-*.xml" })
public class JiraServiceTest {
    @Autowired
    private JiraRestfulUriRepository jiraRestfulUriRepository;

    @Autowired
    private ConfigRepository configRepository;

    @Autowired
    private JiraRestfulUriService jiraRestfulUriService;

    @Autowired
    private JobParamRepository jobParamRepository;

    @Test
    public void findByFunctionsTest() {
        System.out.println(jiraRestfulUriRepository.findByFunctions("changeStatus"));
    }

    @Test
    public void initJiraStatusMapTest() {
        Map<String, String> map = jiraRestfulUriService.initJiraStatusMap("GPCPCOAST-34751");
        for (String key : map.keySet()) {
            System.out.println(key + "=" + map.get(key));
        }
    }

    @Test
    public void changeStatusTest() {
        //System.out.println(configRepository.findValueByKey("ENV"));
        //jiraRestfulUriService.changeStatus("GPCPCOAST-34751");
        //System.out.println(jiraRestfulUriService.getJiraInfo("GPCPCOAST-34751"));
        jiraRestfulUriService.startUpdate("\\\\cangzdwats01\\CoastPackage\\20180830\\application\\jira-list.txt");
    }

    @Test
    public void changeAssigneeTest() {
        jiraRestfulUriService.changeAssignee("GPCPCOAST-34751");
        String path = "\\\\cangzdwats01\\CoastPackage\\20180830\\application\\jira-list.txt";
        System.out.println(jiraRestfulUriService.getFileContentListByNewLine(new File(path)).toString());
    }

}

package com.aiatss.coast.deploymenttool;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aiatss.coast.deploymenttool.bean.jira.Authorization;
import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.domain.service.ConfigService;
import com.aiatss.coast.deploymenttool.util.HttpUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-*.xml" })
public class HttpUtilTest {

    @Autowired
    private ConfigService configService;

    @Test
    public void responseBodyTest() {
        Authorization auth = new Authorization(configService.retrieveConfigValueByKey(Config.LAN_USERNAME),
                configService.retrieveConfigValueByKey(Config.LAN_PASSWORD));
        try {
            URI uri = new URI(
                    "http://cangzpwsvn01:8080/rest/api/2/issue/GPCPCOAST-34751/transitions?expand=transitions.fields");
            System.out.println(HttpUtil.responseBody(uri, HttpMethod.GET, auth));
        }
        catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Test
    public void postTest() {
        Authorization auth = new Authorization(configService.retrieveConfigValueByKey(Config.LAN_USERNAME),
                configService.retrieveConfigValueByKey(Config.LAN_PASSWORD));
        String url = "http://cangzpwsvn01:8080/rest/api/2/issue/GPCPCOAST-34751/transitions?expand=transitions.fields";
        Map<String, Map<String, String>> params = new HashMap<String, Map<String, String>>();
        Map<String, String> map = new HashMap<String, String>();
        map.put("id", "91");//{"transition":{"id":"91"}}
        params.put("transition", map);
        ObjectMapper mapper = new ObjectMapper();
        try {
            String param = mapper.writeValueAsString(params);
            System.out.println(param);
            param = "{\"name\":\"cdcoast02\"}";
            System.out.println(HttpUtil.post(url, param, auth));
            //System.out.println(HttpUtil.post(url, params, auth));
        }
        catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Test
    public void putTest() {
        Authorization auth = new Authorization(configService.retrieveConfigValueByKey(Config.LAN_USERNAME),
                configService.retrieveConfigValueByKey(Config.LAN_PASSWORD));
        String url = "http://cangzpwsvn01:8080/rest/api/2/issue/GPCPCOAST-34751/assignee";
        String param = "{\"name\":\"asnphlj\"}";
        HttpUtil.put(url, param, auth);
    }

    @Test
    public void test() {
        String str = "{\"transition\":{\"id\":\"#id#\"}}";
        //String.format("##", args)
    }
}

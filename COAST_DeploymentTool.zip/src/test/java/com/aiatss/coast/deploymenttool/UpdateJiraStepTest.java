package com.aiatss.coast.deploymenttool;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aiatss.coast.deploymenttool.application.step.UpdateJiraStep;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-*.xml" })
public class UpdateJiraStepTest {
    @Autowired
    private UpdateJiraStep updateJira;

    @Test
    public void executeTest() {
        String json = "{\"pkg_home\":\"\\\\\\\\cangzdwats01\\\\CoastPackage\\\\20180830\\\\application\"}";
        //String json = "{\"pkg_home\":\"jira-list.txt\"}";
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(JsonParser.Feature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER, true);
        //mapper.configure(JsonParser.Feature.ALLOW_YAML_COMMENTS, true);
        JsonNode parameter = null;
        try {
            parameter = mapper.readValue(json, JsonNode.class);
        }
        catch (JsonParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (JsonMappingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        updateJira.execute(1, parameter);
    }
}

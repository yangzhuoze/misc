package com.aiatss.coast.deploymenttool.config;

import com.aiatss.coast.deploymenttool.bean.ScriptTask;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ScriptConfig {
    
    public static final String SCRIPT_STATUS_READY = "READY";
    public static final String SCRIPT_STATUS_RUNNING = "RUNNING";
    public static final String SCRIPT_STATUS_STOPPED = "STOPPED";
    public static final String SCRIPT_STATUS_SUCCESS = "SUCCESS";
    public static final String SCRIPT_STATUS_FAILED = "FAILED";

    public static final String SYSTEM_OS_NAME = "os.name";
    public static final String OS_LINUX = "linux";
    public static final String OS_WINDOWS = "Win";

    public static final String SCRIPT_EXECUTION_LOG_FILE_PREFIX = "script-execution_";

    public static Thread scriptExecutorThread;
    public static String scriptExecutionStatus;
    public static final Object scriptLock = new Object();
    public static List<ScriptTask> loadedScriptTaskList = new ArrayList<>();
    public static List<ScriptTask> scriptTaskList = new ArrayList<>();

    public static String scriptExecutionUsercode;
    public static Date startTimestamp;
    public static long endTimestamp;
    public static File scriptExecutionLogFile;
    public static Integer scriptExecutionId;
}

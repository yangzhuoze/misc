package com.aiatss.coast.deploymenttool.application.controller;

import com.aiatss.coast.deploymenttool.config.HttpConfig;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoginFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse res = (HttpServletResponse) servletResponse;

        String servletPath = req.getPathInfo(); //for WAS Server
        if (StringUtils.isEmpty(servletPath)) {
            servletPath = req.getServletPath(); //for Tomcate Server
        }
        if (isBypassURI(servletPath)) {
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        HttpSession session = req.getSession();
        String currentUser = (String) session.getAttribute(HttpConfig.SESSION_USER_KEY);

        if (req.getRequestURI().startsWith(req.getContextPath() + "/page/login")
                || req.getRequestURI().startsWith(req.getContextPath() + "/secure/login")
                || StringUtils.isNotEmpty(currentUser)) {
            filterChain.doFilter(servletRequest, servletResponse);
        } else {
            res.sendRedirect(req.getContextPath() + "/page/login");
        }
    }

    @Override
    public void destroy() {

    }

    private boolean isBypassURI(String url) {
        String[] bypassURI = {
                "/js", "/css", "/images", "/common", "/auth"
        };
        for (String bypass : bypassURI) {
            if (url.startsWith(bypass)) {
                return true;
            }
        }

        String[] bypassExt = {
                ".js", ".jpg", ".css", ".gif", ".png", ".eot", ".svg", ".ttf", ".woff", ".woff2"
        };
        for (String bypass : bypassExt) {
            if (url.endsWith(bypass)) {
                return true;
            }
        }
        return false;
    }
}

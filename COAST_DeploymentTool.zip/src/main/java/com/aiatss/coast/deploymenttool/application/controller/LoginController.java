package com.aiatss.coast.deploymenttool.application.controller;

import com.aiatss.coast.deploymenttool.bean.view.ResponseBean;
import com.aiatss.coast.deploymenttool.config.HttpConfig;
import com.aiatss.coast.deploymenttool.config.LoginConfig;
import com.aiatss.coast.deploymenttool.domain.service.LoginService;
import com.aiatss.coast.deploymenttool.domain.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.CommunicationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/secure")
public class LoginController {

    private final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

    private final UserService userService;

    private final LoginService loginService;

    @Autowired
    public LoginController(UserService userService, LoginService loginService) {
        this.userService = userService;
        this.loginService = loginService;
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ResponseBody
    public ResponseBean login(HttpServletRequest req, @RequestParam String usercode, @RequestParam String password) {
        try {
            if (loginService.authenticate(usercode, password)) {
                if (userService.performLogin(usercode)) {
                    setCurrentUser(req, usercode);
                    return ResponseBean.buildSuccessResponseBean("page/job");
                } else {
                    return ResponseBean.buildResponseBean(HttpConfig.SUCCESS_CODE,
                            HttpConfig.ERROR_MESSAGE, LoginConfig.MSG_ACCOUNT_NOT_ALLOWED);
                }
            } else {
                return ResponseBean.buildResponseBean(HttpConfig.SUCCESS_CODE,
                        HttpConfig.ERROR_MESSAGE, LoginConfig.MSG_ACCOUNT_INVALID);
            }
        } catch (LoginException e) {
            LOGGER.error("Login error: {}", e);
            return ResponseBean.buildResponseBean(HttpConfig.SUCCESS_CODE, HttpConfig.ERROR_MESSAGE, e);
        } catch (CommunicationException e) {
            LOGGER.error("Connect to authentication server error: {}", e);
            return ResponseBean.buildResponseBean(HttpConfig.SUCCESS_CODE, HttpConfig.ERROR_MESSAGE, e.getMessage());
        }
    }

    @RequestMapping(value = "/logout")
    @ResponseBody
    public ResponseBean logout(HttpServletRequest req) {
        this.removeCurrentUser(req);
        return ResponseBean.buildSuccessResponseBean("/");
    }

    private void sessionNotNull(HttpServletRequest req) {
        if (req == null || req.getSession() == null) {
            throw new RuntimeException();
        }
    }

    private String getCurrentUser(HttpServletRequest req) {
        if (req == null || req.getSession() == null) {
            return null;
        } else {
            Object loginSession = req.getSession().getAttribute(
                    HttpConfig.SESSION_USER_KEY);
            if (loginSession instanceof String) {
                return (String) loginSession;
            } else {
                return null;
            }
        }
    }

    private void setCurrentUser(HttpServletRequest req, String usercode) {
        sessionNotNull(req);
        req.getSession().setAttribute(HttpConfig.SESSION_USER_KEY, usercode);
    }

    private void removeCurrentUser(HttpServletRequest req) {
        sessionNotNull(req);
        req.getSession().removeAttribute(HttpConfig.SESSION_USER_KEY);
    }
}

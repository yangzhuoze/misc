package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.ScriptConfig;
import com.aiatss.coast.deploymenttool.infrastructure.repository.ScriptConfigRepository;
import com.aiatss.coast.deploymenttool.util.IBeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScriptConfigService {

    private final ScriptConfigRepository scriptConfigRepository;

    @Autowired
    public ScriptConfigService(ScriptConfigRepository scriptConfigRepository) {
        this.scriptConfigRepository = scriptConfigRepository;
    }

    public List<ScriptConfig> retrieveScriptConfig() {
        return scriptConfigRepository.findAll();
    }

    public void createScriptConfig(ScriptConfig config) {
        if (scriptConfigRepository.findByName(config.getName()) != null) {
            throw new RuntimeException("Already exist!");
        }
        scriptConfigRepository.save(config);
    }

    public void updateScriptConfig(ScriptConfig newConfig) {
        ScriptConfig config = scriptConfigRepository.findByName(newConfig.getName());
        if (config == null) {
            throw new RuntimeException("Not exist!");
        }
        IBeanUtils.copyProperties(newConfig, config);
        scriptConfigRepository.save(config);
    }

    public void deleteScriptConfig(String name) {
        ScriptConfig config = scriptConfigRepository.findByName(name);
        if (config == null) {
            throw new RuntimeException("Not exist!");
        }
        scriptConfigRepository.delete(config);
    }
}

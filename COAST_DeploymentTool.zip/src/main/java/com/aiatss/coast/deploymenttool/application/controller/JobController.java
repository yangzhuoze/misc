package com.aiatss.coast.deploymenttool.application.controller;

import com.aiatss.coast.deploymenttool.bean.view.JobViewBean;
import com.aiatss.coast.deploymenttool.bean.view.ResponseBean;
import com.aiatss.coast.deploymenttool.config.HttpConfig;
import com.aiatss.coast.deploymenttool.config.JobConfig;
import com.aiatss.coast.deploymenttool.domain.service.JobService;
import com.aiatss.coast.deploymenttool.exception.BusinessException;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/job")
public class JobController {

    private final JobService jobService;

    @Autowired
    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean retrieveJob(String id) {
        if (StringUtils.isEmpty(id)) {
            return ResponseBean.buildSuccessResponseBean(jobService.retrieveJobConfig());
        } else {
            return ResponseBean.buildSuccessResponseBean(jobService.retrieveJobConfigById(Integer.valueOf(id)));
        }
    }

    @RequestMapping(value = "/execute", method = RequestMethod.POST)
    @ResponseBody
    public ResponseBean execute(String id, String step, @RequestBody ObjectNode json) {
        try {
            jobService.execute(id, step, json);
            return ResponseBean.buildEmptySuccessResponseBean();
        } catch (BusinessException e) {
            return ResponseBean.buildResponseBean(HttpConfig.SUCCESS_CODE, e.getMessage(), null);
        }
    }

    @RequestMapping(value = "/status", method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean retrieveJobStatus() {
        return ResponseBean.buildSuccessResponseBean(JobViewBean.buildJobViewBean());
    }

    @RequestMapping(value = "/clean", method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean cleanJobStatus() {
        JobConfig.isJobRunning = false;
        JobConfig.executionResult = null;
        JobConfig.executionParameter = null;
        JobConfig.jobDetailLogFile = null;
        return ResponseBean.buildEmptySuccessResponseBean();
    }
}

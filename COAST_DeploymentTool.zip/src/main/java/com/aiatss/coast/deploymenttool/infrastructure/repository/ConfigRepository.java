package com.aiatss.coast.deploymenttool.infrastructure.repository;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.Config;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConfigRepository extends JpaRepository<Config, Integer> {

    Config findByKey(String key);

    @Query("SELECT value FROM Config WHERE key = :key ")
    String findValueByKey(@Param("key") String key);

    @Query("SELECT value FROM Config WHERE key LIKE :key%")
    List<String> findValuesByKeyLikeStartWith(@Param("key") String key);

    @Query("UPDATE Config SET value = :value WHERE key = :key")
    int updateValueByKey(@Param("key") String key, @Param("value") String value);
}

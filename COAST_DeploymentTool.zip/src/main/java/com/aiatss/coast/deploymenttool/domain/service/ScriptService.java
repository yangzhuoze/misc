package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.application.thread.ScriptExecutorThread;
import com.aiatss.coast.deploymenttool.bean.ScriptTask;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.ScriptConfig;
import com.aiatss.coast.deploymenttool.infrastructure.repository.ScriptConfigRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ScriptService {

    private final ScriptConfigRepository scriptConfigRepository;

    @Autowired
    private final UserService userService;

    private final ScriptExecutorThread scriptExecutorThread;

    @Autowired
    public ScriptService(ScriptConfigRepository scriptConfigRepository, UserService userService, ScriptExecutorThread scriptExecutorThread) {
        this.scriptConfigRepository = scriptConfigRepository;
        this.userService = userService;
        this.scriptExecutorThread = scriptExecutorThread;
    }

    public void load() {
        synchronized (com.aiatss.coast.deploymenttool.config.ScriptConfig.scriptLock) {
            if (com.aiatss.coast.deploymenttool.config.ScriptConfig.SCRIPT_STATUS_RUNNING.equals(com.aiatss.coast.deploymenttool.config.ScriptConfig.scriptExecutionStatus)) {
                throw new RuntimeException("Script is running, can not reload now.");
            }

            List<ScriptTask> initSciptLst = new ArrayList<>();
            List<ScriptConfig> allScript = scriptConfigRepository.findAll();
            for (ScriptConfig config : allScript) {
                initSciptLst.add(getScriptTaskFromScriptConfig(config));
            }

            com.aiatss.coast.deploymenttool.config.ScriptConfig.scriptExecutionStatus = com.aiatss.coast.deploymenttool.config.ScriptConfig.SCRIPT_STATUS_READY;
            com.aiatss.coast.deploymenttool.config.ScriptConfig.loadedScriptTaskList = initSciptLst;
        }
    }

    public List<ScriptConfig> findAllScript() {
        return scriptConfigRepository.findAll();
    }

    public void execute(String[] idList) {
        synchronized (com.aiatss.coast.deploymenttool.config.ScriptConfig.scriptLock) {
            com.aiatss.coast.deploymenttool.config.ScriptConfig.scriptExecutionUsercode = userService.getCurrentUserCode();
            List<ScriptTask> scriptTaskList = loadTaskListFromIdList(idList);
            com.aiatss.coast.deploymenttool.config.ScriptConfig.scriptTaskList = scriptTaskList;

            com.aiatss.coast.deploymenttool.config.ScriptConfig.scriptExecutorThread = new Thread(scriptExecutorThread);
            com.aiatss.coast.deploymenttool.config.ScriptConfig.scriptExecutorThread.start();
        }
    }

    private List<ScriptTask> loadTaskListFromIdList(String[] idList) {
        List<ScriptTask> taskList = new ArrayList<>();
        for (String id : idList) {
            ScriptConfig config = scriptConfigRepository.findOne(Integer.valueOf(id));
            taskList.add(getScriptTaskFromScriptConfig(config));
        }
        return taskList;
    }

    private ScriptTask getScriptTaskFromScriptConfig(ScriptConfig config) {
        ScriptTask task = new ScriptTask();
        task.setId(String.valueOf(config.getId()));
        task.setName(config.getName());
        task.setScript(config.getScript());
        task.setStatus(com.aiatss.coast.deploymenttool.config.ScriptConfig.SCRIPT_STATUS_READY);
        return task;
    }

    private ScriptTask findExecutionById(String id) {
        for (ScriptTask execution : com.aiatss.coast.deploymenttool.config.ScriptConfig.loadedScriptTaskList) {
            if (execution.getId().equals(id)) {
                return execution;
            }
        }
        return null;
    }

}

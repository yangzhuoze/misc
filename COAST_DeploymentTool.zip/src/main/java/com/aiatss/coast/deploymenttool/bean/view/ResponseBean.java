package com.aiatss.coast.deploymenttool.bean.view;

import com.aiatss.coast.deploymenttool.config.HttpConfig;

public class ResponseBean {

    private String resultCode;

    private String resultMessage;

    private transient Object data;

    public ResponseBean(String resultCode, String resultMessage, Object data) {
        this.resultCode = resultCode;
        this.resultMessage = resultMessage;
        this.data = data;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String toString() {
        if (data != null) {
            return "\nResponseBean " + "resultCode: " + resultCode + ", resultMessage: " + resultMessage + "\ndata: " + data.toString();
        } else {
            return "\nResponseBean " + "resultCode: " + resultCode + ", resultMessage: " + resultMessage + "\ndata: ";
        }
    }

    public static ResponseBean buildEmptySuccessResponseBean() {
        return buildSuccessResponseBean(null);
    }

    public static ResponseBean buildSuccessResponseBean(Object data) {
        return buildResponseBean(
                HttpConfig.SUCCESS_CODE,
                HttpConfig.SUCCESS_MESSAGE,
                data);
    }

    public static ResponseBean buildResponseBean(String resultCode, String resultMessage, Object data) {
        return new ResponseBean(resultCode, resultMessage, data);
    }
}

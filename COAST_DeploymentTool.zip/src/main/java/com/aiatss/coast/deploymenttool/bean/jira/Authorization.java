package com.aiatss.coast.deploymenttool.bean.jira;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
public class Authorization {
    private String username;

    private String password;

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Authorization(String username, String password) {
        super();
        this.username = username;
        this.password = password;
    }

}

package com.aiatss.coast.deploymenttool.application.thread;

import com.aiatss.coast.deploymenttool.bean.ScriptTask;
import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.config.ScriptConfig;
import com.aiatss.coast.deploymenttool.domain.service.ConfigService;
import com.aiatss.coast.deploymenttool.domain.service.LogService;
import com.aiatss.coast.deploymenttool.domain.service.ScriptExecutionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.InputStream;
import java.util.Date;

@Component
public class ScriptExecutorThread implements Runnable {

    private final LogService logService;

    private final ConfigService configService;

    private final ScriptExecutionService scriptExecutionService;

    @Autowired
    public ScriptExecutorThread(LogService logService, ConfigService configService, ScriptExecutionService scriptExecutionService) {
        this.logService = logService;
        this.configService = configService;
        this.scriptExecutionService = scriptExecutionService;
    }

    @Override
    public void run() {

        preExecution();

        if (logService == null) {
            throw new RuntimeException("Log service unavailable");
        }

        try {
            for (ScriptTask task : ScriptConfig.scriptTaskList) {
                String scriptPath = task.getScript();
                File script = new File(configService.findAppRelevantPathByFolderName(Config.SCRIPT_FOLDER) + scriptPath);

                if (!script.exists()) {
                    throw new RuntimeException("Script not existed.");
                }
                this.log("Start executing script: " + script);

                String cmdStr;
                if (System.getProperty(ScriptConfig.SYSTEM_OS_NAME).startsWith(ScriptConfig.OS_WINDOWS)) {
                    cmdStr = "cmd /c start \"\" " + script.getAbsolutePath();
                } else {
                    cmdStr = "sh " + script;
                }
                Process proc = Runtime.getRuntime().exec(cmdStr);
                InputStream is = proc.getInputStream();
                int bufInt = 0;
                while ((bufInt = is.read()) > 0) {
                    System.out.println((char) bufInt);
                    log((char) bufInt);
                }
                int exitValue = proc.exitValue();
                log("Exit code: " + exitValue);
            }

            ScriptConfig.scriptExecutionStatus = ScriptConfig.SCRIPT_STATUS_SUCCESS;
        } catch (Exception e) {
            ScriptConfig.scriptExecutionStatus = ScriptConfig.SCRIPT_STATUS_FAILED;
            log("Error in executing script: " + e);
            throw new RuntimeException("Error in executing script: " + e);
        } finally {
            postExecution();
        }
    }

    private void preExecution() {
        ScriptConfig.startTimestamp = new Date();
        ScriptConfig.scriptExecutionStatus = ScriptConfig.SCRIPT_STATUS_RUNNING;

        File logFile = logService.createScriptLogFile();
        ScriptConfig.scriptExecutionLogFile = logFile;
        scriptExecutionService.createExecution(logFile.getName());
    }

    private void postExecution() {
        ScriptConfig.endTimestamp = System.currentTimeMillis();
        scriptExecutionService.endExecution();
    }

    private void log(String content) {
        this.logService.logScriptExecutionLine(content);
    }

    private void log(char content) {
        this.logService.logScriptExecution(String.valueOf(content));
    }

}

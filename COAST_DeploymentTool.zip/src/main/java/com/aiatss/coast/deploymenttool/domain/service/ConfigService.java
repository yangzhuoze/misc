package com.aiatss.coast.deploymenttool.domain.service;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.Config;
import com.aiatss.coast.deploymenttool.infrastructure.repository.ConfigRepository;

import static com.aiatss.coast.deploymenttool.config.Config.PT_PARENT_FOLDER;

@Service
public class ConfigService {

    private final ConfigRepository configRepository;

    @Autowired
    public ConfigService(ConfigRepository configRepository) {
        this.configRepository = configRepository;
    }

    public List<Config> retrieveConfig() {
        return configRepository.findAll();
    }

    public String retrieveConfigValueByKey(String key) {
        Config config = configRepository.findByKey(key);
        if (config != null) {
            return config.getValue().trim();
        }
        else {
            return null;
        }
    }

    public void updateConfig(String key, String value) {
        configRepository.updateValueByKey(key, value);
    }

    public void createConfig(String key, String value) {
        if (configRepository.findByKey(key) != null) {
            throw new RuntimeException("Config already existed!");
        }
        Config config = new Config();
        config.setKey(key);
        config.setValue(value);
        configRepository.save(config);
    }

    public void deleteConfig(String key) {
        Config config = configRepository.findByKey(key);
        if (config == null) {
            throw new RuntimeException("Config not existed!");
        }
        configRepository.delete(config);
    }

    public String findAppRelevantPathByFolderName(String folder) {
        String pathParent = configRepository
                .findValueByKey(PT_PARENT_FOLDER);
        String pathFolder = configRepository.findValueByKey(folder);
        return pathParent + File.separator + pathFolder;
    }

    public String findAppRelevantPathByFolder(String folder) {
        String pathParent = configRepository.findValueByKey(PT_PARENT_FOLDER);
        return pathParent + File.separator + folder;
    }


}

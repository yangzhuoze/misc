package com.aiatss.coast.deploymenttool.infrastructure.repository;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlSequence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SqlSequenceRepository extends JpaRepository<SqlSequence, Integer> {

    List<SqlSequence> findAllBySystem(String system);

    SqlSequence findSqlSequencePoByName(String name);

}

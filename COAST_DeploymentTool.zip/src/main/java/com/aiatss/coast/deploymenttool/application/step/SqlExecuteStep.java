package com.aiatss.coast.deploymenttool.application.step;

import com.aiatss.coast.deploymenttool.config.SqlConfig;
import com.aiatss.coast.deploymenttool.domain.service.SqlConnectionService;
import com.aiatss.coast.deploymenttool.domain.service.SqlExecuteService;
import com.aiatss.coast.deploymenttool.exception.StepException;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlExecute;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.List;

@Component
@Scope(value = "prototype")
public class SqlExecuteStep implements Step {

    private final Logger LOGGER = LoggerFactory.getLogger("SqlLogger");

    private final DataSource dataSource;

    private final SqlExecuteService sqlExecuteService;

    private final SqlConnectionService sqlConnectionService;

    @Autowired
    public SqlExecuteStep(DataSource dataSource, SqlExecuteService sqlExecuteService, SqlConnectionService sqlConnectionService) {
        this.dataSource = dataSource;
        this.sqlExecuteService = sqlExecuteService;
        this.sqlConnectionService = sqlConnectionService;
    }

    @Override
    public void execute(int config, Object parameter) {
        SqlExecute cfgSqlExecute = sqlExecuteService.findById(config);
        if (cfgSqlExecute == null) {
            throw new StepException("Config for sql execute should not be null");
        }
//        DataSource dataSource = sqlConnectionService.buildDataSource(cfgSqlExecute.getConnection());

        // TODO if sql file not exists, won't throw err.k
        List<File> files = sqlExecuteService.getFilesBySequences(cfgSqlExecute);
        for (File file : files) {
            Connection conn;
            try {
                conn = dataSource.getConnection();
                LOGGER.info("Connected to database.");
            } catch (SQLException e) {
                LOGGER.error("Error while getting database connection: {}", e);
                throw new StepException(e);
            }

            String sql = null;
            Statement cstmt = null;
            try {
                LOGGER.info("Start execute SQL file : " + file);

                sql = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
                String[] stmts = sql.split("[\n\r][ \t]*[Gg][Oo][ \t]*(?!.)");
                for (String stmt : stmts) {
                    conn.setAutoCommit(false);
                    cstmt = conn.createStatement();
                    boolean execute = cstmt.execute(stmt);
                    if (!execute) {
                        int updateCount = cstmt.getUpdateCount();
                        LOGGER.info("Update count: " + updateCount);
                    }
                    SQLWarning warning = cstmt.getWarnings();
                    while (warning != null) {
                        LOGGER.info("Warning :" + warning.getMessage());
                        warning = warning.getNextWarning();

                    }
                    cstmt.close();
                }
                conn.commit();
            } catch (Exception e) {
                try {
                    conn.rollback();
                    conn.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
                LOGGER.info("Execute sql with Exception : " + e.getMessage());
                LOGGER.info(sql);
                SqlConfig.sqlExecutionStatus = SqlConfig.SQL_STATUS_FAILED;
                e.printStackTrace();
                throw new RuntimeException(e);
            } finally {
                if (cstmt != null) {
                    try {
                        cstmt.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                LOGGER.info("End execute SQL file: {}", file);
            }
        }
    }
}

package com.aiatss.coast.deploymenttool.bean.view;

import com.aiatss.coast.deploymenttool.bean.ScriptTask;
import com.aiatss.coast.deploymenttool.config.ScriptConfig;

import java.util.List;

public class ScriptViewBean {

    private String status;

    private List<ScriptTask> loadedScriptTaskList;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<ScriptTask> getLoadedScriptTaskList() {
        return loadedScriptTaskList;
    }

    public void setLoadedScriptTaskList(List<ScriptTask> loadedScriptTaskList) {
        this.loadedScriptTaskList = loadedScriptTaskList;
    }

    public ScriptViewBean() {
        this.status = ScriptConfig.scriptExecutionStatus;
        this.loadedScriptTaskList = ScriptConfig.loadedScriptTaskList;
    }
}

package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.application.thread.SqlExecutorThread;
import com.aiatss.coast.deploymenttool.bean.SqlTask;
import com.aiatss.coast.deploymenttool.config.SqlConfig;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.Config;
import com.aiatss.coast.deploymenttool.infrastructure.repository.ConfigRepository;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SqlService {

    private final ConfigRepository configRepository;

    private final SqlSequenceService sqlSequenceService;

    private final UserService userService;

    private final SqlExecutorThread sqlExecutorThread;

    @Autowired
    public SqlService(ConfigRepository configRepository,
                      SqlSequenceService sqlSequenceService,
                      UserService userService,
                      SqlExecutorThread sqlExecutorThread) {
        this.configRepository = configRepository;
        this.sqlSequenceService = sqlSequenceService;
        this.userService = userService;
        this.sqlExecutorThread = sqlExecutorThread;
    }

    /**
     * Execute load / reload task from .sql file
     */
    public void load() {
        synchronized (SqlConfig.sqlLock) {
            if (!SqlConfig.sqlTaskList.isEmpty()) {
                SqlConfig.sqlTaskList.clear();
            }

            List<String> dbSystemList = configRepository.findValuesByKeyLikeStartWith(com.aiatss.coast.deploymenttool.config.Config.SQL_EXECUTION);
            Map<String, List<String>> dbPathMap = sqlSequenceService.findPathsBySystems(dbSystemList);
            Map<String, List<String>> dbFileMap = new HashMap<>();

            for (Map.Entry<String, List<String>> entry : dbPathMap.entrySet()) {
                String dbSystem = entry.getKey();
                String sqlPath = this.getSqlPath(dbSystem);
                List<String> sysPathList = new ArrayList<>();
                for (String regex : entry.getValue()) {
                    regex = sqlPath + regex;
                    List<String> dirPathList = com.aiatss.coast.deploymenttool.util.FileUtils.getFilePathList(sqlPath, regex);
                    sysPathList.addAll(dirPathList);
                }
                dbFileMap.put(dbSystem, sysPathList);
            }

            SqlConfig.sqlExecutionStatus = SqlConfig.SQL_STATUS_READY;
            initSqlTaskFromPath(dbFileMap);
        }
    }

    /**
     * @param system The database system that will execute the sql.
     * @param no The index of the sql file in the task list.
     * @return The sql file content
     */
    public String descript(String system, String no) {
        List<SqlTask> taskList = SqlConfig.sqlTaskList.get(system);
        for (SqlTask task : taskList) {
            if (task.getNo().equals(no)) {
                try {
                    return FileUtils.readFileToString(new File(task.getFile()), StandardCharsets.UTF_8);
                } catch (IOException e) {
                    e.printStackTrace();
                    throw new RuntimeException("SQL File not existed.");
                }
            }
        }

        return null;
    }

    /**
     *
     */
    public void execute() {
        synchronized (SqlConfig.sqlLock) {
            SqlConfig.sqlExecutionUsercode = userService.getCurrentUserCode();
            SqlConfig.sqlExecutorThread = new Thread(sqlExecutorThread);
            SqlConfig.sqlExecutorThread.start();
        }
    }

    private String getSqlPath(String dbSystem) {
        Config sqlPath = configRepository.findByKey(com.aiatss.coast.deploymenttool.config.Config.SQL_PATH_PREFIX);
        Config systemPath = configRepository.findByKey(com.aiatss.coast.deploymenttool.config.Config.DB_FOLDER_PREFIX_ + dbSystem);
        return sqlPath.getValue() + systemPath.getValue();
    }

    private void initSqlTaskFromPath(Map<String, List<String>> dbPathMap) {
        HashMap<String, List<SqlTask>> taskMap = new HashMap<>();
        for (Map.Entry<String, List<String>> entry : dbPathMap.entrySet()) {
            String system = entry.getKey();
            List<SqlTask> taskList = new ArrayList<>();
            for (String filename : entry.getValue()) {
                SqlTask sqlTask = new SqlTask();
                sqlTask.setNo(String.valueOf(taskList.size()));
                sqlTask.setFile(filename);
                sqlTask.setStatus(SqlConfig.SQL_EXECUTE_RESULT_PENDING);
                sqlTask.setSystem(system);
                taskList.add(sqlTask);
            }
            taskMap.put(system, taskList);
        }
        SqlConfig.sqlTaskList = taskMap;
    }
}

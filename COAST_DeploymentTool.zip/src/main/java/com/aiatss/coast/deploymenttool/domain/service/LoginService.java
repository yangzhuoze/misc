package com.aiatss.coast.deploymenttool.domain.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import java.io.File;
import java.net.URI;

@Service
public class LoginService implements InitializingBean {
    private static final Logger logger = LoggerFactory.getLogger(LoginService.class);
    private boolean isIBMJVM = System.getProperty("java.vendor").toUpperCase().contains("IBM");
    private Configuration loginConfig;

    private boolean _authenticate(final String userId, final String password) throws LoginException {
        LoginContext loginContext = null;
        try {
            CallbackHandler handler = new CallbackHandler() {
                @Override
                public void handle(Callback[] callbacks) {
                    for (Callback callback : callbacks)
                        if (callback instanceof NameCallback) {
                            NameCallback nameCallback = (NameCallback) callback;
                            nameCallback.setName(userId);
                        } else if (callback instanceof PasswordCallback) {
                            PasswordCallback passCallback = (PasswordCallback) callback;
                            passCallback.setPassword(password.toCharArray());
                        } else if (!isIBMJVM) {
                            throw new RuntimeException("Unsupported Callback: "
                                    + callback.getClass().getName());
                        }
                }
            };

            if (isIBMJVM) {
                loginContext = new LoginContext(
                        "spnego-client_ibm", null,
                        handler, loginConfig);
            } else {
                loginContext = new LoginContext(
                        "spnego-client_sun", null,
                        handler, loginConfig);
            }
            loginContext.login();
            return true;
        } catch (FailedLoginException e) {
            return false;
        } catch (Exception ex) {
            logger.error("{}", ex);
            return false; // "Login Failed: " + ex.getMessage();
        } finally {
            if (loginContext != null) {
                loginContext.logout();
            }
        }
    }

    public boolean authenticate(String userId, String password) throws LoginException {
        if (isIBMJVM) {
            return _authenticate(userId.toUpperCase(), password) || _authenticate(userId.toLowerCase(), password);
        }
        return _authenticate(userId, password);
    }

    private void init() {
        try {
            File file = new ClassPathResource("login/login.conf").getFile();
            logger.info("The config file is located in " + file.getAbsolutePath());
            String className = isIBMJVM ? "com.ibm.security.auth.login.ConfigFile"
                    : "com.sun.security.auth.login.ConfigFile";
            loginConfig = ((Configuration) Class.forName(className)
                    .getConstructor(new Class[]{URI.class})
                    .newInstance(new Object[]{file.toURI()}));

            System.setProperty("java.security.krb5.conf",
                    new ClassPathResource("login/krb5.conf").getFile().getAbsolutePath());
            System.setProperty("java.security.krb5.kdc", "cncspwdom01.aia.biz");
            System.setProperty("java.security.krb5.realm", "AIA.BIZ");
        } catch (Exception ex) {
            logger.error("Login Configuration Error: {}", ex);
        }
    }

    @Override
    public void afterPropertiesSet() {
        init();
    }

    public static void main(String[] args) {
        LoginService ls = new LoginService();
        ls.init();
        try {
            System.out.println(ls.authenticate("asnphm4", ""));
        } catch (LoginException e) {
            logger.error("{}", e);
        }
    }

}

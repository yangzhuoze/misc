package com.aiatss.coast.deploymenttool.application.thread;

import com.aiatss.coast.deploymenttool.bean.SqlTask;
import com.aiatss.coast.deploymenttool.config.SqlConfig;
import com.aiatss.coast.deploymenttool.domain.service.ExecutionService;
import com.aiatss.coast.deploymenttool.domain.service.LogService;
import com.aiatss.coast.deploymenttool.domain.service.SqlConnectionService;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Component
public class SqlExecutorThread implements Runnable {

    @Autowired
    private LogService logService;

    @Autowired
    private ExecutionService sqlExecutionService;

    @Autowired
    private SqlConnectionService sqlConnectionService;

    @Override
    public void run() {

        try {

            this.preExecution();

            for (Entry<String, List<SqlTask>> entry : SqlConfig.sqlTaskList.entrySet()) {
                log("Try to connect database system: " + entry.getKey());
                DataSource dataSource = null;
                Connection conn = null;
                try {
                    dataSource = sqlConnectionService.getDataSourceBySystem(entry.getKey());
                    conn = dataSource.getConnection();
                } catch (SQLException e) {
                    e.printStackTrace();
                    log(e.toString());
                    throw new RuntimeException(String.format("Initial SQL connection error, DataSource: %s, Connection: %s",
                            dataSource, conn));
                }
                log("Connected to database: " + entry.getKey());

                for (SqlTask task : entry.getValue()) {

                    if (SqlConfig.SQL_STATUS_STOPPED.equals(SqlConfig.sqlExecutionStatus)) {
                        task.setStatus(SqlConfig.SQL_EXECUTE_RESULT_STOPPED);
                        continue;
                    }

                    task.setStatus(SqlConfig.SQL_EXECUTE_RESULT_RUNNING);
                    String sql = null;
                    Statement cstmt = null;

                    if (conn != null) {
                        try {
                            log("Start execute SQL file : " + task.getFile());

                            File file = new File(task.getFile());
                            sql = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
                            String[] stmts = sql.split("[\n\r][ \t]*[Gg][Oo][ \t]*(?!.)");
                            for (String stmt : stmts) {
                                conn.setAutoCommit(false);
                                cstmt = conn.createStatement();
                                boolean execute = cstmt.execute(stmt);
                                if (!execute) {
                                    int updateCount = cstmt.getUpdateCount();
                                    log("Update count: " + updateCount);
                                }
                                SQLWarning warning = cstmt.getWarnings();
                                while (warning != null) {
                                    log("Warning :" + warning.getMessage());
                                    warning = warning.getNextWarning();

                                }
                                cstmt.close();
                            }
                            conn.commit();
                            task.setStatus(SqlConfig.SQL_EXECUTE_RESULT_SUCCESS);
                        } catch (Exception e) {
                            try {
                                conn.rollback();
                                conn.close();
                            } catch (SQLException e1) {
                                e1.printStackTrace();
                            }
                            log("Execute sql with Exception : " + e.getMessage());
                            log(sql);
                            task.setStatus(SqlConfig.SQL_EXECUTE_RESULT_FAILED);
                            SqlConfig.sqlExecutionStatus = SqlConfig.SQL_STATUS_FAILED;
                            e.printStackTrace();
                            throw new RuntimeException();
                        } finally {
                            if (cstmt != null) {
                                try {
                                    cstmt.close();
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                            }
                            log("End execute SQL file : " + task.getFile());
                        }
                    } else {
                        throw new RuntimeException();
                    }
                }
            }

            SqlConfig.sqlExecutionStatus = SqlConfig.SQL_STATUS_SUCCESS;
        } catch (Exception e) {
            SqlConfig.sqlExecutionStatus = SqlConfig.SQL_STATUS_FAILED;
            throw new RuntimeException(e);
        } finally {
            this.postExecution();
        }
    }

    private void preExecution() {
        SqlConfig.startTimestamp = new Date();
        SqlConfig.sqlExecutionStatus = SqlConfig.SQL_STATUS_RUNNING;

        this.resetSqlTaskStatus();
        File logFile = logService.createSqlLogFile();
        SqlConfig.sqlExecutionLogFile = logFile;
        sqlExecutionService.createExecution(logFile.getName());
    }

    private void postExecution() {
        SqlConfig.endTimestamp = new Date();
        sqlExecutionService.endExecution();
    }

    private void resetSqlTaskStatus() {
        if (!SqlConfig.sqlTaskList.isEmpty()) {
            for (Map.Entry<String, List<SqlTask>> entry : SqlConfig.sqlTaskList.entrySet()) {
                for (SqlTask task : entry.getValue()) {
                    task.setStatus(SqlConfig.SQL_EXECUTE_RESULT_PENDING);
                }
            }
        }
    }

    private void log(String content) {
        logService.logSqlExecution(content);
    }

}

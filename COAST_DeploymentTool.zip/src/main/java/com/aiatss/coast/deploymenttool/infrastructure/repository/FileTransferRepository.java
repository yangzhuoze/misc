package com.aiatss.coast.deploymenttool.infrastructure.repository;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.FileTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FileTransferRepository extends JpaRepository<FileTransfer, Integer> {
}

package com.aiatss.coast.deploymenttool.exception;

import com.aiatss.coast.deploymenttool.bean.view.ResponseBean;
import com.aiatss.coast.deploymenttool.config.HttpConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice(annotations = {Controller.class})
public class GlobalControllerExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalControllerExceptionHandler.class);

    @ResponseBody
    @ExceptionHandler(Throwable.class)
    public ResponseBean handleConflict(final Throwable t) {
        LOGGER.error(t.getMessage(), t);
        return ResponseBean.buildResponseBean(HttpConfig.ERROR_CODE, HttpConfig.ERROR_MESSAGE, t.getMessage());
    }

}

package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlSequence;
import com.aiatss.coast.deploymenttool.infrastructure.repository.SqlSequenceRepository;
import com.aiatss.coast.deploymenttool.util.IBeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SqlSequenceService {

    private final SqlSequenceRepository sqlSequenceRepository;

    @Autowired
    public SqlSequenceService(SqlSequenceRepository sqlSequenceRepository) {
        this.sqlSequenceRepository = sqlSequenceRepository;
    }

    public Map<String, List<String>> findPathsBySystems(List<String> dbSystems) {
        HashMap<String, List<String>> dbPathMap = new HashMap<>();
        for (String system : dbSystems) {
            List<SqlSequence> sequenceList = sqlSequenceRepository.findAllBySystem(system);
            Collections.sort(sequenceList);
            dbPathMap.put(system, this.getPathsBySequences(sequenceList));
        }
        return dbPathMap;
    }

    private List<String> getPathsBySequences(List<SqlSequence> sequenceList) {
        List<String> pathList = new ArrayList<>();
        for (SqlSequence seq : sequenceList) {
            pathList.add(seq.getPath());
        }
        return pathList;
    }

    public List<SqlSequence> retrieveSqlSequence() {
        return sqlSequenceRepository.findAll();
    }

    public void deleteSqlSequence(String name) {
        SqlSequence sequence = sqlSequenceRepository.findSqlSequencePoByName(name);
        sqlSequenceRepository.delete(sequence);
    }

    public void createSqlSequence(SqlSequence sequence) {
        if (sqlSequenceRepository.findSqlSequencePoByName(sequence.getName()) != null) {
            throw new RuntimeException(sequence.getName() + " already exist!");
        }
        sqlSequenceRepository.save(sequence);
    }

    public void updateSqlSequence(SqlSequence newSequence) {
        SqlSequence sequence = sqlSequenceRepository.findSqlSequencePoByName(newSequence.getName());
        if (sequence == null) {
            throw new RuntimeException("Can't find sequence by name: " + sequence.getName());
        }
        IBeanUtils.copyProperties(newSequence, sequence);
        sqlSequenceRepository.save(sequence);

    }
}

package com.aiatss.coast.deploymenttool.config.spring;

import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.domain.service.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.ldap.core.ContextSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.pool.factory.PoolingContextSource;
import org.springframework.ldap.pool.validation.DefaultDirContextValidator;
import org.springframework.ldap.transaction.compensating.manager.TransactionAwareContextSourceProxy;

import javax.annotation.PostConstruct;

@Configuration
@EnableConfigurationProperties
@PropertySource("classpath:config.properties")
public class LdapConfig {

    private LdapTemplate ldapTemplate;

    private final ConfigService configService;

    @Autowired
    public LdapConfig(ConfigService configService) {
        this.configService = configService;
    }

    @Bean
    @PostConstruct
    @ConfigurationProperties(prefix = "ldap.contextSource")
    public LdapContextSource contextSource() {
//        config.put("java.naming.ldap.attributes.binary", "objectGUID");
//        contextSource.setBaseEnvironmentProperties(config);
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setPooled(true);
        contextSource.setUserDn(configService.retrieveConfigValueByKey(Config.LAN_USERNAME));
        contextSource.setPassword(configService.retrieveConfigValueByKey(Config.LAN_PASSWORD));
        return contextSource;
    }

    @Bean
    @ConfigurationProperties(prefix = "ldap.poolingContextSource")
    public ContextSource poolingLdapContextSource() {
        PoolingContextSource poolingContextSource = new PoolingContextSource();
        poolingContextSource.setDirContextValidator(new DefaultDirContextValidator());
        poolingContextSource.setContextSource(contextSource());

        return new TransactionAwareContextSourceProxy(poolingContextSource);
    }

    @Bean
    public LdapTemplate ldapTemplate() {
        if (null == ldapTemplate) {
            ldapTemplate = new LdapTemplate(poolingLdapContextSource());
            ldapTemplate.setIgnorePartialResultException(true);
        }
        return ldapTemplate;
    }

}

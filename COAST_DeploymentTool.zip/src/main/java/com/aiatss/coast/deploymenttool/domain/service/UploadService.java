package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.FileUpload;
import com.aiatss.coast.deploymenttool.infrastructure.repository.FileUploadRepository;
import com.aiatss.coast.deploymenttool.util.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class UploadService {

    @Autowired
    private FileUploadRepository fileUploadRepository;

    public List<FileUpload> retrieveUploadConfig() {
        return fileUploadRepository.findAll();
    }

    public void updateUploadConfigByType(String type, String path, String description) {
        FileUpload config = fileUploadRepository.findByTypeIgnoreCase(type);
        if (config == null) {
            throw new RuntimeException("Can't find config");
        }
        if (StringUtils.isNotEmpty(path)) config.setPath(path);
        if (StringUtils.isNotEmpty(description)) config.setDescription(description);
        fileUploadRepository.save(config);
    }

    public void createUploadConfig(String type, String path, String description) {
        if (fileUploadRepository.findByTypeIgnoreCase(type) != null) {
            throw new RuntimeException("Already existed");
        }
        FileUpload config = new FileUpload();
        config.setType(type);
        config.setPath(path);
        config.setDescription(description);
        fileUploadRepository.save(config);
    }

    public void deleteUploadConfig(String type) {
        FileUpload config = fileUploadRepository.findByTypeIgnoreCase(type);
        if (config != null) {
            fileUploadRepository.delete(config);
        } else {
            throw new RuntimeException("Can't find config");
        }
    }

    public void uploadFile(MultipartFile file, String path) throws Exception {
        FileUtils.uploadFileToDestFolder(file, path);
    }
}

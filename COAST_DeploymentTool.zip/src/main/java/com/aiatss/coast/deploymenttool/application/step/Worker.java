package com.aiatss.coast.deploymenttool.application.step;

import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.config.JobConfig;
import com.aiatss.coast.deploymenttool.domain.service.ConfigService;
import com.aiatss.coast.deploymenttool.domain.service.JobExecutionService;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobDefinition;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobExecution;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.StepDefinition;
import com.aiatss.coast.deploymenttool.util.SpringContextUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Component
@Scope("prototype")
public class Worker implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger("JobLogger");

    private final static Lock lock = new ReentrantLock();

    private final ConfigService configService;

    private final JobExecutionService jobExecutionService;

    private JobExecution execution;

    private String stepIndex;

    private Object parameter;

    @Autowired
    public Worker(ConfigService configService, JobExecutionService jobExecutionService) {
        this.configService = configService;
        this.jobExecutionService = jobExecutionService;
    }

    @Override
    public void run() {
        if (lock.tryLock()) {
            JobConfig.isJobRunning = true;
            JobConfig.executionParameter = parameter;
            JobConfig.logContent = new StringBuilder();
            JobConfig.jobDetailLogValue = new SimpleDateFormat("yyyy-MM-dd'T'hhmmss").format(execution.getStartTime());
            JobConfig.jobDetailLogFile = new File(configService.findAppRelevantPathByFolderName(Config.LOG_FOLDER)
                    + String.format("/job/job-execution-%s.log", JobConfig.jobDetailLogValue));
            MDC.put(JobConfig.JOB_LOG_KEY, JobConfig.jobDetailLogValue);
            LOGGER.info("Create job execution.");
            jobExecutionService.updateJob(execution);
            String jobName = execution.getJob().getName();

            try {
                LOGGER.info("Start execute job: {}", jobName);
                JobDefinition job = execution.getJob();
                JobConfig.logContent.append("Start execute job: ").append(job.getName()).append("\n");
                List<StepDefinition> steps = job.getSteps();

                for (StepDefinition stepDefinition : steps.subList(this.getStepIndex(), steps.size())) {
                    Step step = SpringContextUtils.getBean(stepDefinition.getBean());
                    if (step != null) {
                        JobConfig.logContent.append("Running step: ").append(stepDefinition.getName()).append("...");
                        step.execute(stepDefinition.getConfig(), parameter);
                        JobConfig.logContent.append("Done!\n");
                    }
                }
                JobConfig.logContent.append("Complete job execution!");
                LOGGER.info("Execute job success: {}", jobName);
                JobConfig.executionResult = JobConfig.RESULT_SUCCESS;
            } catch (Exception ex) {
                JobConfig.logContent.append("Failed!\n").append("Execute job failed: ").append(ex.getMessage());
                LOGGER.error("Error stack trace: {}", ex);
                LOGGER.error("Execute job failed: {}", jobName);
                JobConfig.executionResult = JobConfig.RESULT_FAILED + ": " + ex.getMessage();
            } finally {
                JobConfig.isJobRunning = false;
                jobExecutionService.updateJob(execution);
                MDC.remove(JobConfig.JOB_LOG_KEY);
                lock.unlock();
            }
        } else {
            throw new RuntimeException("There is job running, can't execute run job.");
        }
    }

    public int getStepIndex() {
        return Integer.parseInt(stepIndex);
    }

    public void setStepIndex(String stepIndex) {
        this.stepIndex = stepIndex;
    }

    public void setExecution(JobExecution execution) {
        this.execution = execution;
    }

    public void setParameter(Object parameter) {
        this.parameter = parameter;
    }
}

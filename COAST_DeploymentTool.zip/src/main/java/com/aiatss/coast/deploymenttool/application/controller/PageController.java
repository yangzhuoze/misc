package com.aiatss.coast.deploymenttool.application.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/page")
public class PageController {

    @RequestMapping("/job")
    public String job() {
        return "job";
    }

    @RequestMapping("/user")
    public String user() {
        return "users";
    }

    @RequestMapping("/login")
    public String login() {
        return "login";
    }

    @RequestMapping("/upload")
    public String upload() {
        return "upload";
    }

    @RequestMapping("/sql")
    public String sql() {
        return "sql";
    }

    @RequestMapping("/script")
    public String script() {
        return "script";
    }

    @RequestMapping("/test")
    @ResponseBody
    public String test() {
        return "test";
    }

}

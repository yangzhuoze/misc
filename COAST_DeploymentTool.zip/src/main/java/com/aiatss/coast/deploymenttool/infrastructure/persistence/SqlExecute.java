package com.aiatss.coast.deploymenttool.infrastructure.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "DtTblSqlExecute")
public class SqlExecute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "ConnectionId")
    private SqlConnection connection;

    private String pathPrefix;

    @Fetch(FetchMode.SELECT)
    @OrderBy(value = "priority")
    @OneToMany(mappedBy = "execute", fetch = FetchType.EAGER)
    private List<SqlSequence> sequences;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SqlConnection getConnection() {
        return connection;
    }

    public void setConnection(SqlConnection connection) {
        this.connection = connection;
    }

    public String getPathPrefix() {
        return pathPrefix;
    }

    public void setPathPrefix(String pathPrefix) {
        this.pathPrefix = pathPrefix;
    }

    public List<SqlSequence> getSequences() {
        return sequences;
    }

    public void setSequences(List<SqlSequence> sequences) {
        this.sequences = sequences;
    }
}

package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobParam;
import com.aiatss.coast.deploymenttool.infrastructure.repository.JobParamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobParamService {

    private final JobParamRepository jobParamRepository;

    @Autowired
    public JobParamService(JobParamRepository jobParamRepository) {
        this.jobParamRepository = jobParamRepository;
    }

    public List<JobParam> retrieveJobParamByJobId(int jobId) {
        return jobParamRepository.findByJob_Id(jobId);
    }
}

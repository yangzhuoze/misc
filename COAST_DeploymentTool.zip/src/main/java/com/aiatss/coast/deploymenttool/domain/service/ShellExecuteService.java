package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.ShellExecute;
import com.aiatss.coast.deploymenttool.infrastructure.repository.ShellExecuteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShellExecuteService {

    private final ShellExecuteRepository shellExecuteRepository;

    @Autowired
    public ShellExecuteService(ShellExecuteRepository shellExecuteRepository) {
        this.shellExecuteRepository = shellExecuteRepository;
    }

    public ShellExecute findById(int id) {
        return shellExecuteRepository.findOne(id);
    }
}

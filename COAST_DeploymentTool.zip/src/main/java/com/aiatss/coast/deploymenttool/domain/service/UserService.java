package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.bean.ldap.LdapUser;
import com.aiatss.coast.deploymenttool.config.HttpConfig;
import com.aiatss.coast.deploymenttool.config.ScriptConfig;
import com.aiatss.coast.deploymenttool.config.SqlConfig;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.User;
import com.aiatss.coast.deploymenttool.infrastructure.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Date;
import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;

    private final LoginService loginService;

    private final LdapService ldapService;

    @Autowired
    public UserService(UserRepository userRepository, LoginService loginService, LdapService ldapService) {
        this.userRepository = userRepository;
        this.loginService = loginService;
        this.ldapService = ldapService;
    }

    public List<User> findAllUser() {
        return userRepository.findAll();
    }

    public boolean performLogin(String userCode) {
        LdapUser ldapUser = ldapService.findUserInGroup(userCode);
        if (ldapUser == null) {
            return false;
        } else {
            User user = userRepository.findByUserCode(userCode);
            if (user == null) {
                user = new User();
            }

            user.setUserCode(userCode);
            user.setUserName(ldapUser.getUserName());
            user.setGivenName(ldapUser.getGivenName());
            user.setEmail(ldapUser.getMail());
            user.setLastLoginDate(new Date());
            userRepository.save(user);
            return true;
        }
    }

    public String getCurrentUserCode() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return (String) attr.getRequest().getSession().getAttribute(HttpConfig.SESSION_USER_KEY);
    }

    public User getCurrentUser() {
        return userRepository.findByUserCode(getCurrentUserCode());
    }

    public User getSqlConfigUser() {
        return userRepository.findByUserCode(SqlConfig.sqlExecutionUsercode);
    }

    public User getScriptConfigUser() {
        return userRepository.findByUserCode(ScriptConfig.scriptExecutionUsercode);
    }

}

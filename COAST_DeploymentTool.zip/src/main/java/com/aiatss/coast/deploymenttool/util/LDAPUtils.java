package com.aiatss.coast.deploymenttool.util;

import com.aiatss.coast.deploymenttool.bean.ldap.LdapUser;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import java.util.Hashtable;

public class LDAPUtils {

    public static LdapUser findUserDetailByCodeAndPassword(String code, String password) throws NamingException {
        Hashtable<String, String> ht = new Hashtable<String, String>();
        ht.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        ht.put(Context.PROVIDER_URL, "ldap://aia.biz:389/");
        ht.put(Context.SECURITY_AUTHENTICATION, "simple");
        ht.put(Context.SECURITY_PRINCIPAL, "AIA\\" + code);
        ht.put(Context.SECURITY_CREDENTIALS, password);

        DirContext dc = new InitialDirContext(ht);
        String root = "DC=AIA,DC=BIZ";
        SearchControls ctrl = new SearchControls();
        ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
        NamingEnumeration<SearchResult> answer = dc.search(root, "sAMAccountName=" + code, ctrl);

        SearchResult result = answer.next();
        NamingEnumeration<? extends Attribute> attrs = result.getAttributes().getAll();
        LdapUser user = new LdapUser();
        user.setUserCode(code);
        while (attrs.hasMore()) {
            Attribute attr = attrs.next();
            if (attr.getID().equalsIgnoreCase("mail")) {
                user.setMail((String) attr.get());
            }
            if (attr.getID().equalsIgnoreCase("name")) {
                user.setUserName((String) attr.get());
            }
        }

        return user;
    }

}

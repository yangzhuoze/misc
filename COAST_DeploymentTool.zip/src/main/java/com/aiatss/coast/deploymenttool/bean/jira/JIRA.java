package com.aiatss.coast.deploymenttool.bean.jira;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
public class JIRA {
    private Assignee assignee;

    private Reporter reporter;

    private String status;

    private String issuetype;

    private long maxResivion;

    public Assignee getAssignee() {
        return assignee;
    }

    public void setAssignee(Assignee assignee) {
        this.assignee = assignee;
    }

    public long getMaxResivion() {
        return maxResivion;
    }

    public void setMaxResivion(long maxResivion) {
        this.maxResivion = maxResivion;
    }

    public Reporter getReporter() {
        return reporter;
    }

    public void setReporter(Reporter reporter) {
        this.reporter = reporter;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIssuetype() {
        return issuetype;
    }

    public void setIssuetype(String issuetype) {
        this.issuetype = issuetype;
    }

    @Override
    public String toString() {
        return "JIRA [assignee=" + assignee + ", reporter=" + reporter + ", status=" + status + ", issuetype="
                + issuetype + ", maxResivion=" + maxResivion + "]";
    }

    public JIRA(Assignee assignee, Reporter reporter, String status, String issuetype, long maxResivion) {
        super();
        this.assignee = assignee;
        this.reporter = reporter;
        this.status = status;
        this.issuetype = issuetype;
        this.maxResivion = maxResivion;
    }

    public JIRA(Assignee assignee, Reporter reporter, String status, String issuetype) {
        super();
        this.assignee = assignee;
        this.reporter = reporter;
        this.status = status;
        this.issuetype = issuetype;
    }

}

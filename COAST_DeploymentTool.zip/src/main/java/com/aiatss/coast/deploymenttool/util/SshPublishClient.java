package com.aiatss.coast.deploymenttool.util;

import com.aiatss.coast.deploymenttool.exception.StepException;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.ServerInfo;
import com.jcraft.jsch.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class SshPublishClient {

    private static final Logger SFTP_LOGGER = LoggerFactory.getLogger("FileTransferLogger");
    private static final Logger SSH_LOGGER = LoggerFactory.getLogger("ShellLogger");

    private static final String CHANNEL_SFTP = "sftp";
    private static final String CHANNEL_EXEC = "exec";

    private static final int CHAR_END = 0xffffffff;
    private static final int CHAR_LINE = 0xA;

    private ServerInfo server;
    private Session session;
    private ChannelSftp sftpChannel = null;
    private ChannelExec execChannel = null;

    public SshPublishClient(ServerInfo server) throws JSchException {
        this.server = server;
        this.connect();
    }

    private void connect() throws JSchException {
        JSch jsch = new JSch();
        Session session = jsch.getSession(server.getUsername(), server.getHost(), server.getPort());
        session.setConfig("StrictHostKeyChecking", "no");

        String pubKeyPath = server.getPubKeyPath();
        String passPhrase = server.getPassPhrase();
        String password = server.getPassword();
        if (StringUtils.isNotEmpty(pubKeyPath)) {
            if (StringUtils.isNotEmpty(passPhrase)) {
                jsch.addIdentity(pubKeyPath, passPhrase);
            } else {
                jsch.addIdentity(pubKeyPath);
            }
        } else if (StringUtils.isNotEmpty(password)) {
            session.setPassword(password);
        } else {
            throw new IllegalArgumentException("No Authorization.");
        }

        session.connect();
        this.session = session;
    }

    public void upload(String localPath, String remotePath) throws JSchException, SftpException {
        remotePath = URLUtils.formatDirectory(remotePath);
        if (this.sftpChannel == null) {
            sftpChannel = (ChannelSftp) session.openChannel(CHANNEL_SFTP);
            sftpChannel.connect();
            SFTP_LOGGER.info("[SFTP] Connected to server: {}", server.getHost());
        }

        File localFile = new File(localPath);
        if (!localFile.exists()) {
            throw new IllegalArgumentException("No local file found." + localPath);
        }

        if (localFile.isDirectory()) {
            File[] files = localFile.listFiles();
            if (files == null || files.length == 0) {
                SFTP_LOGGER.info("Empty local sub folder: {}", localPath);
                return;
            }

            for (File file : files) {
                String filePath = file.getAbsolutePath();
                if (file.isDirectory()) {
                    upload(filePath, remotePath + file.getName());
                } else {
                    this.mkdirs(remotePath);
                    sftpChannel.put(filePath, remotePath + file.getName(), ChannelSftp.OVERWRITE);
                    SFTP_LOGGER.info("Transfer done: {}", filePath);
                }
            }
        } else {
            this.mkdirs(remotePath);
            sftpChannel.put(localPath, remotePath + localFile.getName(), ChannelSftp.OVERWRITE);
            SFTP_LOGGER.info("Transfer done: {}", localPath);
        }
    }

    public void download(String localPath, String remotePath) throws SftpException, JSchException, IOException {
        localPath = URLUtils.formatDirectory(localPath);
        if (this.sftpChannel == null) {
            sftpChannel = (ChannelSftp) session.openChannel(CHANNEL_SFTP);
            sftpChannel.connect();
            SFTP_LOGGER.info("[SFTP] Connected to server: {}", server.getHost());
        }
        File localFile = new File(localPath);
        if (!localFile.exists() || !localFile.isDirectory()) {
            localFile.mkdirs();
        } else {
            FileUtils.cleanDirectory(localFile);
        }

        SftpATTRS stat;
        try {
            stat = sftpChannel.stat(remotePath);
        } catch (SftpException e) {
            if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
                throw new IllegalArgumentException("No remote file found: " + remotePath);
            } else {
                throw e;
            }
        }

        if (stat.isDir()) {
            remotePath = URLUtils.formatDirectory(remotePath);
            for (Object lsEntry : sftpChannel.ls(remotePath)) {
                if (!(lsEntry instanceof ChannelSftp.LsEntry)) {
                    SFTP_LOGGER.error("Unable to ls all file: {}", remotePath);
                    break;
                }
                String filename = ((ChannelSftp.LsEntry) lsEntry).getFilename();
                if ("..".equals(filename) || ".".equals(filename)) {
                    continue;
                }

                if (sftpChannel.stat(remotePath + filename).isDir()) {
                    download(localPath + filename, remotePath + filename);
                } else {
                    sftpChannel.get(remotePath + filename, localPath + filename);
                    SFTP_LOGGER.info("Transfer done: {}", filename);
                }
            }
        } else {
            sftpChannel.get(remotePath, localPath + ((ChannelSftp.LsEntry) sftpChannel.ls(remotePath).get(0)).getFilename());
            SFTP_LOGGER.info("Transfer done: {}", remotePath);
        }
    }

    public void disconnect() {
        if (this.session != null) {
            session.disconnect();
        }
        if (this.sftpChannel != null) {
            this.sftpChannel.disconnect();
            SFTP_LOGGER.info("Disconnected from server: {}", this.server.getHost());
        }
        if (this.execChannel != null) {
            this.execChannel.disconnect();
            SSH_LOGGER.info("Disconnected from server: {}", this.server.getHost());
        }
    }

    private void mkdirs(String path) {
        try {
            this.sftpChannel.cd(path);
        } catch (SftpException e) {
            if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
                mkdirs(path.substring(0, path.lastIndexOf("/")));
                if (!path.endsWith("/")) {
                    try {
                        this.sftpChannel.mkdir(path);
                    } catch (SftpException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        }
    }

    public void execute(String script) throws JSchException, IOException {
        execChannel = (ChannelExec) session.openChannel(CHANNEL_EXEC);
        SSH_LOGGER.info("[SSH] Connected to server: {}", server.getHost());

        String command = "sh " + script + " 2>&1 \\n";
        execChannel.setCommand(command);
        InputStream commandOutput = execChannel.getInputStream();
        execChannel.connect();

        int readByte = commandOutput.read();

        do {
            while (commandOutput.available() > 0) {
                StringBuilder lineBuf = new StringBuilder();
                while (readByte != CHAR_LINE) {
                    lineBuf.append((char) readByte);
                    readByte = commandOutput.read();
                }
                SSH_LOGGER.info("[CONSOLE] {}", lineBuf.toString());
                readByte = commandOutput.read();
                if (readByte < 0) {
                    break;
                }
            }
        } while (!execChannel.isClosed() || commandOutput.available() > 0);

        int exitCode = execChannel.getExitStatus();
        if (exitCode != 0) {
            // TODO Should handle ErrStream
//            String errMsg = readLine(execChannel.getErrStream());
//            SSH_LOGGER.error("[SSH] Script error message: {}", errMsg);
            throw new StepException("[SSH] Script execute failed with exit code: " + exitCode);
        }
        SSH_LOGGER.info("[SSH] Script execution done successfully.");
        execChannel.disconnect();
    }

    private String readLine(InputStream in) throws IOException {
        int readByte = in.read();
        StringBuilder lineBuf = new StringBuilder();
        while (readByte != CHAR_LINE && readByte != CHAR_END) {
            lineBuf.append((char) readByte);
            readByte = in.read();
        }
        return lineBuf.toString();
    }
}

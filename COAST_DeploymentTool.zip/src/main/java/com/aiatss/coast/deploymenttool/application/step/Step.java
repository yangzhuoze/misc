package com.aiatss.coast.deploymenttool.application.step;

public interface Step {
    void execute(int config, Object parameter);
}

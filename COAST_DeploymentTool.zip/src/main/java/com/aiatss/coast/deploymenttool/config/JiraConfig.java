package com.aiatss.coast.deploymenttool.config;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
public class JiraConfig {
    public static final String GET_JIRA_TRANSITIONSINFO = "getJiraTransitionsInfo";

    public static final String GET_JIRA_INFO = "getJiraInfo";

    public static final String CHANGE_ASSIGNEE = "changeAssignee";

    public static final String CHANGE_STATUS = "changeStatus";

    public static final String TRANSITIONS = "transitions";

    public static final String ID = "id";

    public static final String NAME = "name";

    public static final String FIELDS = "fields";

    public static final String ASSIGNEE = "assignee";

    public static final String REPORTER = "reporter";

    public static final String DISPLAY_NAME = "displayName";

    public static final String ISSUE_TYPE = "issuetype";

    public static final String STATUS = "status";

    public static final String ENV_UAT = "UAT";

    public static final String ENV_PROD = "PROD";
}

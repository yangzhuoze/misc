package com.aiatss.coast.deploymenttool.application.step;

import com.aiatss.coast.deploymenttool.domain.service.ShellExecuteService;
import com.aiatss.coast.deploymenttool.exception.StepException;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.ServerInfo;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.ShellExecute;
import com.aiatss.coast.deploymenttool.util.SshPublishClient;
import com.jcraft.jsch.JSchException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@Scope(value = "prototype")
public class ShellExecuteStep implements Step {

    private static final Logger LOGGER = LoggerFactory.getLogger("ShellLogger");

    private final ShellExecuteService shellExecuteService;

    @Autowired
    public ShellExecuteStep(ShellExecuteService shellExecuteService) {
        this.shellExecuteService = shellExecuteService;
    }

    @Override
    public void execute(int config, Object parameter) {
        ShellExecute cfgShell = shellExecuteService.findById(config);
        if (cfgShell == null || StringUtils.isEmpty(cfgShell.getPath())) {
            throw new StepException("Config for script should not be null");
        }
        ServerInfo server = cfgShell.getServer();
        String script = cfgShell.getPath();
        LOGGER.info("Start shell execute step: execute {} on {}", script, server.getHost());
        if (!"ssh".equals(server.getProtocol())) {
            throw new StepException("Can't execute shell on remote using protocol other than SSH: using {}", server.getProtocol());
        }

        SshPublishClient client = null;
        try {
            client = new SshPublishClient(server);
            client.execute(script);
        } catch (JSchException e) {
            throw new StepException("[SSH] Error while connecting server: {}", e);
        } catch (IOException e) {
            throw new StepException("[SSH] Error in operating stream: {}", e);
        } finally {
            if (client != null) {
                client.disconnect();
            }
        }

        LOGGER.info("Finish running step with config {}: Run script {} on {}",
                config, script, server.getHost());
    }
}

package com.aiatss.coast.deploymenttool.application.controller;

import com.aiatss.coast.deploymenttool.bean.view.ResponseBean;
import com.aiatss.coast.deploymenttool.domain.service.*;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.ScriptConfig;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlConnection;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlSequence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping(value = "/config")
public class ConfigController {

    private final ConfigService configService;

    private final UploadService uploadService;

    private final SqlConnectionService sqlConnectionService;

    private final SqlSequenceService sqlSequenceService;

    private final ScriptConfigService scriptConfigService;

    @Autowired
    public ConfigController(ConfigService configService,
                            UploadService uploadService,
                            SqlConnectionService sqlConnectionService,
                            SqlSequenceService sqlSequenceService,
                            ScriptConfigService scriptConfigService) {
        this.configService = configService;
        this.uploadService = uploadService;
        this.sqlConnectionService = sqlConnectionService;
        this.sqlSequenceService = sqlSequenceService;
        this.scriptConfigService = scriptConfigService;
    }

    // Start configuration for TblConfig
    @RequestMapping(value = "/config", method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean retrieveConfig() {
        return ResponseBean.buildSuccessResponseBean(configService.retrieveConfig());
    }

    @RequestMapping(value = "/config", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseBean updateConfig(String key, String value) {
        configService.updateConfig(key, value);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/config", method = RequestMethod.POST)
    @ResponseBody
    public ResponseBean createConfig(String key, String value) {
        configService.createConfig(key, value);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/config", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseBean deleteConfig(String key) {
        configService.deleteConfig(key);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    // Start configuration for TblFileUpload
    @RequestMapping(value = "/upload", method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean retrieveUpload() {
        return ResponseBean.buildSuccessResponseBean(uploadService.retrieveUploadConfig());
    }

    @RequestMapping(value = "/upload", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseBean updateUpload(String type, String path, String description) {
        uploadService.updateUploadConfigByType(type, path, description);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    @ResponseBody
    public ResponseBean createUpload(String type, String path,
                                     String description) {
        uploadService.createUploadConfig(type, path, description);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/upload", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseBean deleteUpload(String type) {
        uploadService.deleteUploadConfig(type);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    // Start configuration for TblSqlConnection
    @RequestMapping(value = "/sqlconnection", method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean retrieveSqlConnection() {
        return ResponseBean.buildSuccessResponseBean(sqlConnectionService.retrieveSqlConnection());
    }

    @RequestMapping(value = "/sqlconnection", method = RequestMethod.POST)
    @ResponseBody
    public ResponseBean createSqlConnection(SqlConnection connection) {
        sqlConnectionService.createSqlConnConfig(connection);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/sqlconnection", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseBean updateSqlConnection(SqlConnection connection) {
        sqlConnectionService.updateSqlConnConfig(connection);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/sqlconnection", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseBean deleteSqlConnection(String system) {
        sqlConnectionService.deleteSqlConnConfig(system);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    // Start configuration for TblSQLSequence
    @RequestMapping(value = "/sqlsequence", method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean retrieveSqlSequence() {
        return ResponseBean.buildSuccessResponseBean(sqlSequenceService.retrieveSqlSequence());
    }

    @RequestMapping(value = "/sqlsequence", method = RequestMethod.POST)
    @ResponseBody
    public ResponseBean createSqlSequence(SqlSequence sequence) {
        sqlSequenceService.createSqlSequence(sequence);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/sqlsequence", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseBean updateSqlSequence(SqlSequence sequence) {
        sqlSequenceService.updateSqlSequence(sequence);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/sqlsequence", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseBean deleteSqlSequence(String name) {
        sqlSequenceService.deleteSqlSequence(name);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    // Start configuration for TblScriptConfig
    @RequestMapping(value = "/scriptconfig", method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean retrieveScriptConfig() {
        return ResponseBean.buildSuccessResponseBean(scriptConfigService.retrieveScriptConfig());
    }

    @RequestMapping(value = "/scriptconfig", method = RequestMethod.POST)
    @ResponseBody
    public ResponseBean createScriptConfig(ScriptConfig config) {
        scriptConfigService.createScriptConfig(config);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/scriptconfig", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseBean updateScriptConfig(ScriptConfig config) {
        scriptConfigService.updateScriptConfig(config);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/scriptconfig", method = RequestMethod.DELETE)
    @ResponseBody
    public ResponseBean deleteScriptConfig(String name) {
        scriptConfigService.deleteScriptConfig(name);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

}

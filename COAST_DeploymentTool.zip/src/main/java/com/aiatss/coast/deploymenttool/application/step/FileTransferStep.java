package com.aiatss.coast.deploymenttool.application.step;

import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.domain.service.ConfigService;
import com.aiatss.coast.deploymenttool.domain.service.FileTransferService;
import com.aiatss.coast.deploymenttool.exception.StepException;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.FileTransfer;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.ServerInfo;
import com.aiatss.coast.deploymenttool.util.SmbUtils;
import com.aiatss.coast.deploymenttool.util.SshPublishClient;
import com.aiatss.coast.deploymenttool.util.URLUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import jcifs.smb.NtlmPasswordAuthentication;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;

@Component
@Scope(value = "prototype")
public class FileTransferStep implements Step {

    private static final Logger LOGGER = LoggerFactory.getLogger("FileTransferLogger");

    private static final String DIRECTION_GET = "GET";
    private static final String DIRECTION_PUT = "PUT";

    private static final String PROTOCOL_SMB = "smb";
    private static final String PROTOCOL_SFTP = "sftp";
//    private static final String PROTOCOL_FTP = "ftp";

    private static final String DEPLOY_PROPERTIES = "deploy.properties";

    private final FileTransferService fileTransferService;

    private final ConfigService configService;

    @Autowired
    public FileTransferStep(FileTransferService fileTransferService, ConfigService configService) {
        this.fileTransferService = fileTransferService;
        this.configService = configService;
    }

    @Override
    public void execute(int config, Object parameter) { // {"pkg_home": "/CoastPackage/20180101/"}
        FileTransfer cfgTransfer = fileTransferService.findById(config);
        if (cfgTransfer == null) {
            throw new StepException("Config for file transfer should not be null");
        }

        ServerInfo server = cfgTransfer.getServer();
        String protocol = server.getProtocol();
        String localPath = cfgTransfer.getLocalPath();
        String remotePath = cfgTransfer.getRemotePath();
        String direction = cfgTransfer.getDirection();

        if (parameter instanceof ObjectNode) {
            Map jsonMap = new ObjectMapper().convertValue(parameter, Map.class);
            localPath = StringSubstitutor.replace(localPath, jsonMap);
            remotePath = StringSubstitutor.replace(remotePath, jsonMap);
        }

        LOGGER.info("Start file transfer step: {} remote path [{}] to/from local path [{}]",
                direction, remotePath, server.getHost());

        if (FileTransferStep.PROTOCOL_SMB.equals(protocol)) {
            // Samba config settings for speed up
            jcifs.Config.setProperty("jcifs.resolveOrder", "DNS");
            jcifs.Config.setProperty("jcifs.smb.client.dfs.disabled", "false");

            String user = server.getUsername();
            String password = server.getPassword();
            if (StringUtils.isEmpty(user) || StringUtils.isEmpty(password)) {
                user = configService.retrieveConfigValueByKey(Config.LAN_USERNAME);
                password = configService.retrieveConfigValueByKey(Config.LAN_PASSWORD);
            }
            NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", user, password);
            remotePath = URLUtils.URLBuilder(protocol, server.getHost(), server.getPort(), remotePath);
            try {
                if (FileTransferStep.DIRECTION_GET.equals(direction)) {
                    SmbUtils.download(localPath, remotePath, auth);
                } else if (DIRECTION_PUT.equals(direction)) {
                    SmbUtils.upload(localPath, remotePath, auth);
                }
            } catch (IOException e) {
                throw new StepException("[SMB] Error while transfer file: %s", e);
            } catch (IllegalArgumentException e) {
                throw new StepException(e);
            }
        } else if (FileTransferStep.PROTOCOL_SFTP.equals(protocol)) {
            SshPublishClient client = null;
            try {
                client = new SshPublishClient(server);
                if (FileTransferStep.DIRECTION_GET.equals(direction)) {
                    client.download(localPath, remotePath);
                } else if (FileTransferStep.DIRECTION_PUT.equals(direction)) {
                    client.upload(localPath, remotePath);
                }
            } catch (JSchException | SftpException e) {
                throw new StepException("[SFTP] Error while connecting server: %s", e);
            } catch (IllegalArgumentException e) {
                throw new StepException(e);
            } catch (IOException e) {
                throw new StepException("[SFTP] Error while transfer file: %s", e);
            } finally {
                if (client != null) {
                    client.disconnect();
                }
            }
        }

        LOGGER.info("Finish running step with config {}: {} remote path [{}] to/from local path [{}]",
                config, direction, remotePath, server.getHost());
    }
}

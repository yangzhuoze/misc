package com.aiatss.coast.deploymenttool.infrastructure.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "DtTblJobParam")
public class JobParam {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @JsonIgnore
    @ManyToOne()
    @JoinColumn(name = "JobId")
    private JobDefinition job;

    @Column(name = "`Key`", nullable = false)
    private String key;

    @Column(nullable = false)
    private String value;

    @Column(nullable = false)
    private String tag;

    @Column(nullable = false)
    private String type;

    private String isHidden;

    private String isRerunCriteria;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public JobDefinition getJob() {
        return job;
    }

    public void setJob(JobDefinition job) {
        this.job = job;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIsHidden() {
        return isHidden;
    }

    public void setIsHidden(String isHidden) {
        this.isHidden = isHidden;
    }

    public String getIsRerunCriteria() {
        return isRerunCriteria;
    }

    public void setIsRerunCriteria(String isRerunCriteria) {
        this.isRerunCriteria = isRerunCriteria;
    }
}

package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlConnection;
import com.aiatss.coast.deploymenttool.infrastructure.repository.SqlConnectionRepository;
import com.aiatss.coast.deploymenttool.util.IBeanUtils;
import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.List;

@Service
public class SqlConnectionService {

    private final SqlConnectionRepository sqlConnectionRepository;

    @Autowired
    public SqlConnectionService(SqlConnectionRepository sqlConnectionRepository) {
        this.sqlConnectionRepository = sqlConnectionRepository;
    }

    public DataSource getDataSourceBySystem(String system) {
        SqlConnection sqlConn = sqlConnectionRepository.findSqlConnectionPoBySystem(system);
        return buildDataSource(sqlConn);
    }

    public DataSource getDataSourceById(int connId) {
        SqlConnection sqlConn = sqlConnectionRepository.findOne(connId);
        return buildDataSource(sqlConn);
    }

    public DataSource buildDataSource(SqlConnection sqlConn) {
        if ("JNDI".equals(sqlConn.getType())) {
            JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
            dataSourceLookup.setResourceRef(true);
            DataSource jndiDataSource = dataSourceLookup.getDataSource(sqlConn.getJndiName());
            return jndiDataSource;
        } else {
            DruidDataSource jdbcDataSource = new DruidDataSource();
            jdbcDataSource.setDriverClassName(sqlConn.getDriver());
            jdbcDataSource.setUrl(sqlConn.getUrl());
            jdbcDataSource.setUsername(sqlConn.getUsername());
            jdbcDataSource.setPassword(sqlConn.getPassword());
            jdbcDataSource.setMaxWait(5000);
            return jdbcDataSource;
        }
    }

    public List<SqlConnection> retrieveSqlConnection() {
        return sqlConnectionRepository.findAll();
    }

    public void createSqlConnConfig(SqlConnection connection) {
        if (sqlConnectionRepository.findSqlConnectionPoBySystem(connection.getSystem()) != null) {
            throw new RuntimeException("Already exist connection with same system name");
        }
        sqlConnectionRepository.save(connection);
    }

    public void updateSqlConnConfig(SqlConnection newConnection) {
        SqlConnection connection = sqlConnectionRepository.findSqlConnectionPoBySystem(newConnection.getSystem());
        if (connection == null) {
            throw new RuntimeException("Can't find connection with system name: " + connection.getSystem());
        }
        IBeanUtils.copyProperties(newConnection, connection);
        sqlConnectionRepository.save(connection);
    }

    public void deleteSqlConnConfig(String system) {
        SqlConnection connection = sqlConnectionRepository.findSqlConnectionPoBySystem(system);
        if (connection == null) {
            throw new RuntimeException("Can't find connection with system name: " + system);
        }
        sqlConnectionRepository.delete(connection);
    }
}

package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.bean.ldap.LdapUser;
import com.aiatss.coast.deploymenttool.config.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.stereotype.Service;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

@Service
public class LdapService {

    private final LdapTemplate ldapTemplate;

    private final ConfigService configService;

    @Autowired
    public LdapService(LdapTemplate ldapTemplate, ConfigService configService) {
        this.ldapTemplate = ldapTemplate;
        this.configService = configService;
    }

    public LdapUser findUserInGroup(String userCode) {
        try {
            LdapQuery ldapQuery = query().where("sAMAccountName").is(userCode)
                    .and("memberOf").is(configService.retrieveConfigValueByKey(Config.LDAP_GROUP));
            LdapUser user = ldapTemplate.findOne(ldapQuery, LdapUser.class);
            return user;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

}

package com.aiatss.coast.deploymenttool.infrastructure.persistence;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "DtTblJobMaster")
public class JobDefinition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String name;

    private String description;

    @Fetch(FetchMode.SELECT)
    @OrderBy(value = "id")
    @OneToMany(mappedBy = "job", fetch = FetchType.EAGER)
    private List<JobParam> params;

    @Fetch(FetchMode.SELECT)
    @OrderBy(value = "priority")
    @OneToMany(mappedBy = "job", fetch = FetchType.EAGER)
    private List<StepDefinition> steps;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<JobParam> getParams() {
        return params;
    }

    public void setParams(List<JobParam> params) {
        this.params = params;
    }

    public List<StepDefinition> getSteps() {
        return steps;
    }

    public void setSteps(List<StepDefinition> steps) {
        this.steps = steps;
    }
}

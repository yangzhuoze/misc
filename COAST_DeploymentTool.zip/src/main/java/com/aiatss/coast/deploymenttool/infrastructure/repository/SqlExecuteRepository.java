package com.aiatss.coast.deploymenttool.infrastructure.repository;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlExecute;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SqlExecuteRepository extends JpaRepository<SqlExecute, Integer> {
}

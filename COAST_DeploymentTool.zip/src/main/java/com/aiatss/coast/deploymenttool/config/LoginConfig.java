package com.aiatss.coast.deploymenttool.config;

public class LoginConfig {

    public static final String MSG_ACCOUNT_INVALID = "Username or password invalid.\nOr your account is locked.";

    public static final String MSG_ACCOUNT_NOT_ALLOWED = "Your account is not allowed to login.";

}

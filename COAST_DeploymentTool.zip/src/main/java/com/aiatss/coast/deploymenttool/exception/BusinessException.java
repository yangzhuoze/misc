package com.aiatss.coast.deploymenttool.exception;

public class BusinessException extends RuntimeException {

    private String errMessage;

    public BusinessException(String errMessage, Object... args) {
        super(String.format(errMessage, args));
    }
    
}

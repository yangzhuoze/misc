package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.config.JobConfig;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobExecution;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobDefinition;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobParam;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.User;
import com.aiatss.coast.deploymenttool.infrastructure.repository.JobExecutionRepository;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class JobExecutionService {

    private final JobExecutionRepository jobExecutionRepository;

    @Autowired
    public JobExecutionService(JobExecutionRepository jobExecutionRepository) {
        this.jobExecutionRepository = jobExecutionRepository;
    }

    public JobExecution createNonPersistJobExecution(JobDefinition job, User user) {
        JobExecution execution = new JobExecution();
        execution.setJob(job);
        execution.setUser(user);
        execution.setStartTime(new Date());
        return execution;
    }

    public JobExecution createJobExecution(JobDefinition job, User user) {
        JobExecution execution = new JobExecution();
        execution.setJob(job);
        execution.setUser(user);
        execution.setStartTime(new Date());
        jobExecutionRepository.save(execution);
        return execution;
    }

    public void updateJob(JobExecution job) {
        job.setResult(JobConfig.executionResult);
        job.setLogFile(JobConfig.jobDetailLogFile.getName());
        job.setParameter(JobConfig.executionParameter.toString());
        if (!JobConfig.isJobRunning) {
            job.setEndTime(new Date());
        }
        jobExecutionRepository.save(job);
    }

    public List<JobExecution> findJobExecutionByRerunIdentifier(String identifier) {
        if (StringUtils.isEmpty(identifier)) {
            return null;
        } else return jobExecutionRepository.findAllByRerunIdentifier(identifier);
    }

    /**
     * 1. Find all JobParam by IsRerunCriteria = 'Y'.
     * 2. Build identifier according to the list:
     *    RerunIdentifier = '_' + json.param1.value + '_' + json.param2.value ...
     * 3. Find JobExecution by identifier.
     * @param job Job that is to be run.
     * @param json Json object passed from form.
     * @return If have been run, return JobExecution, else return null.
     */
    public String buildExecutionIdentifierByJSON(JobDefinition job, ObjectNode json) {
        StringBuilder builder = new StringBuilder();
        for (JobParam param : job.getParams()) {
            if ("Y".equals(param.getIsRerunCriteria())) {
                builder.append("_").append(json.get(param.getKey()).asText());
            }
        }
        String identifier = builder.toString();
        return StringUtils.isEmpty(identifier) ? null : identifier;
    }
}

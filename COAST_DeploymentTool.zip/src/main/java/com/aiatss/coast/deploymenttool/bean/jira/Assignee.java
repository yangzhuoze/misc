package com.aiatss.coast.deploymenttool.bean.jira;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
public class Assignee {
    private String name;

    private String displayName;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public Assignee(String name, String displayName) {
        super();
        this.name = name;
        this.displayName = displayName;
    }

}

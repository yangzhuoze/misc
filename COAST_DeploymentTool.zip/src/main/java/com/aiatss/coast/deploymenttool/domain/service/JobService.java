package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.application.step.Worker;
import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.config.JobConfig;
import com.aiatss.coast.deploymenttool.exception.BusinessException;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobDefinition;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobExecution;
import com.aiatss.coast.deploymenttool.infrastructure.repository.JobMasterRepository;
import com.aiatss.coast.deploymenttool.util.SpringContextUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Properties;

@Service
public class JobService {

    private final JobMasterRepository jobMasterRepository;

    private final JobExecutionService jobExecutionService;

    private final StepService stepService;

    private final UserService userService;

    private final ConfigService configService;

    @Autowired
    public JobService(JobMasterRepository jobMasterRepository, JobExecutionService jobExecutionService, StepService stepService, UserService userService, ConfigService configService) {
        this.jobMasterRepository = jobMasterRepository;
        this.jobExecutionService = jobExecutionService;
        this.stepService = stepService;
        this.userService = userService;
        this.configService = configService;
    }

    public List<JobDefinition> retrieveJobConfig() {
        List<JobDefinition> jobList = jobMasterRepository.findAll();
        for (JobDefinition job : jobList) {
            stepService.setupCfgObject(job.getSteps());
        }
        return jobList;
    }

    public JobDefinition retrieveJobConfigById(int id) {
        JobDefinition job = jobMasterRepository.findOne(id);
        if (job == null) {
            throw new IllegalArgumentException("Can't find job by id: " + id);
        }
        stepService.setupCfgObject(job.getSteps());
        return job;
    }

    public void execute(String id, String step, ObjectNode json) {
        if (JobConfig.isJobRunning) {
            throw new BusinessException("There is job running right now, can't execute run job.");
        }

        JobDefinition job = retrieveJobConfigById(Integer.valueOf(id));
        String identifier = jobExecutionService.buildExecutionIdentifierByJSON(job, json);

        /**
         * Comment due to not fully finish function
         *
        List<JobExecution> executed = jobExecutionService.findJobExecutionByRerunIdentifier(identifier);
        if (!CollectionUtils.isEmpty(executed)) {
            if (!isRerunProperty(job, json)) {
                StringBuilder builder = new StringBuilder();
                builder.append("Can't perform executing, this job with specific parameter have been executed as below. ")
                        .append("If you want to re-execute, please contact system manager.").append("\n");
                for (JobExecution e : executed) {
                    builder.append("\tBy ").append(e.getUser().getUserName())
                            .append(" At ").append(e.getStartTime()).append("\n");
                }
                throw new BusinessException(builder.toString());
            }
        }
         */

        Worker worker = SpringContextUtils.getBean("worker");
        if (worker == null) {
            throw new RuntimeException("Can't find available worker.");
        }

        JobExecution execution = jobExecutionService.createNonPersistJobExecution(job, userService.getCurrentUser());
        execution.setRerunIdentifier(identifier);
        worker.setExecution(execution);
        worker.setStepIndex(step);
        worker.setParameter(json);
        Thread thread = new Thread(worker);
        thread.start();
    }

    private boolean isRerunProperty(JobDefinition job, ObjectNode json) {
        // TODO to add below hard-coded String into config table for configuring.
        JsonNode propPathKey = json.get("pkg_home");
        if (propPathKey == null) {
            return false;
        }
        String propPath = propPathKey.asText();
        if (StringUtils.isEmpty(propPath)) {
            return false;
        }
        SmbFile propFile = null;
        try {
            propFile = new SmbFile("smb://CANGZDWATS01:445/" + propPathKey + "/deploy.properties",
                    new NtlmPasswordAuthentication("AIA",
                            configService.retrieveConfigValueByKey(Config.LAN_USERNAME),
                            configService.retrieveConfigValueByKey(Config.LAN_PASSWORD))
            );
            if (!propFile.exists()) {
                return false;
            }
            Properties prop = new Properties();
            prop.load(propFile.getInputStream());
            String rerun = prop.getProperty("_is_re_deploy");
            if (StringUtils.isNotEmpty(rerun)) {
                return rerun.equals("true");
            }
        } catch (IOException e) {
            return false;
        }
        return false;
    }
}

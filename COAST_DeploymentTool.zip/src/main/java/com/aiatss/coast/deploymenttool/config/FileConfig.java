package com.aiatss.coast.deploymenttool.config;

public class FileConfig {

    public static final String DIRECTORY_TEMP_FILE = "/tmp/";

    public static final String SYS_OS_NAME = "os.name";
    public static final String OS_NAME_LINUX = "linux";
    public static final String OS_NAME_WINDOWS = "win";

    public static final String SHELL_CHMOD_ROOT = "chmod 755 ";

}

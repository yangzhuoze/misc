package com.aiatss.coast.deploymenttool.infrastructure.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "DtTblUser")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String userName;

    @Column(nullable = false)
    private String userCode;

    private String givenName;

    private String email;

    private String status = "A";

    private String isAdmin = "N";

    private Date lastLoginDate;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "DtTblUserPermission",
               joinColumns = @JoinColumn(name = "UserId", referencedColumnName = "Id"),
               inverseJoinColumns = @JoinColumn(name = "PermissionId", referencedColumnName = "Id"))
    private List<Permission> permissions = new ArrayList<>();

    @JsonIgnore
    @OneToMany(mappedBy = "user")
    private List<SqlExecution> sqlExecutions = new ArrayList<>();

    @JsonIgnore
    @OneToMany(mappedBy = "user")
    private List<ScriptExecution> scriptExecutions = new ArrayList<>();

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(String isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Date getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(Date lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public List<Permission> getPermissions() {
        return permissions;
    }

    public void setPermissions(List<Permission> permissions) {
        this.permissions = permissions;
    }

    public List<SqlExecution> getSqlExecutions() {
        return sqlExecutions;
    }

    public void setSqlExecutions(List<SqlExecution> sqlExecutions) {
        this.sqlExecutions = sqlExecutions;
    }
}

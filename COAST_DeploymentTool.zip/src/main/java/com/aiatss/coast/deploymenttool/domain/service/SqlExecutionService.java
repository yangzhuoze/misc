package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.config.SqlConfig;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlExecution;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.User;
import com.aiatss.coast.deploymenttool.infrastructure.repository.SqlExecutionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SqlExecutionService implements ExecutionService {

    private final SqlExecutionRepository sqlExecutionRepository;

    @Autowired
    private final UserService userService;

    @Autowired
    public SqlExecutionService(SqlExecutionRepository sqlExecutionRepository, UserService userService) {
        this.userService = userService;
        this.sqlExecutionRepository = sqlExecutionRepository;
    }

    @Override
    public void createExecution(String fileLog) {
        User user = userService.getSqlConfigUser();

        SqlExecution execution = new SqlExecution();
        execution.setLogFile(fileLog);
        execution.setStartTime(SqlConfig.startTimestamp);
        execution.setUser(user);
        execution.setResult(SqlConfig.SQL_EXECUTE_RESULT_PENDING);
        SqlExecution savedExecution = sqlExecutionRepository.save(execution);
        SqlConfig.sqlExecutionId = savedExecution.getId();
    }

    @Override
    public void endExecution() {
        SqlExecution execution = sqlExecutionRepository.findOne(SqlConfig.sqlExecutionId);
        execution.setEndTime(SqlConfig.endTimestamp);
        execution.setResult(SqlConfig.sqlExecutionStatus);
        sqlExecutionRepository.save(execution);
    }

}

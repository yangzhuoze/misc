package com.aiatss.coast.deploymenttool.util;

import com.aiatss.coast.deploymenttool.config.FileConfig;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class FileUtils {

    private static final String FILE_SEPARATOR_REGEX = "[/\\\\]";

    public static void uploadFileToDestFolder(MultipartFile uploadedFile, String path) throws Exception {
        File folder = new File(path);
        File file = new File(folder, uploadedFile.getOriginalFilename());

        if (!folder.exists()) {
            folder.mkdirs();
        } else {
            if (file.exists()) {
                File folderTmp = new File(FileConfig.DIRECTORY_TEMP_FILE);
                if (!folderTmp.exists()) {
                    folderTmp.mkdirs();
                }
                File fileExisted = new File(FileConfig.DIRECTORY_TEMP_FILE + file.getName()
                        + "_" + System.currentTimeMillis() + ".tmp");
                file.renameTo(fileExisted);
            }
        }

        uploadedFile.transferTo(file);

        if (System.getProperty(FileConfig.SYS_OS_NAME).equalsIgnoreCase(FileConfig.OS_NAME_LINUX)) {
            String shStr = FileConfig.SHELL_CHMOD_ROOT + file;
            Process proc = Runtime.getRuntime().exec(shStr);
            proc.waitFor();
        }
    }

    private static String formatPathToRegex(String path) {
        path = ".*" + path + ".*";
        return path.replace("/", FILE_SEPARATOR_REGEX);
    }

    public static List<String> getFilePathList(String directory, String regex) {
        regex = formatPathToRegex(regex);
        File file = new File(directory);
        List<String> filepathList = new ArrayList<>();
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files == null) {
                return filepathList;
            }
            for (File subFile : files) {
                if (subFile.isDirectory()) {
                    filepathList.addAll(FileUtils.getFilePathList(subFile.getAbsolutePath(), regex));
                } else {
                    if (subFile.getAbsolutePath().matches(regex)) {
                        filepathList.add(subFile.getAbsolutePath());
                    }
                }
            }
            Collections.sort(filepathList);
        }
        return filepathList;
    }

    public static List<File> getFilesByPaths(Collection<String> paths) {
        List<File> files = new ArrayList<>();
        for (String path : paths) {
            files.add(new File(path));
        }
        return files;
    }

    public static List<File> getFilesByDirReg(String directory, String regex) {
        List<String> filePathList = FileUtils.getFilePathList(directory, regex);
        return getFilesByPaths(filePathList);
    }

}

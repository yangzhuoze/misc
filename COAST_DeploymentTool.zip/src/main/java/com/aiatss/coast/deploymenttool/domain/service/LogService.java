package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.config.ScriptConfig;
import com.aiatss.coast.deploymenttool.config.SqlConfig;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service
public class LogService {

    private static final String LOG_EXTENSION = ".log";

    private static final String LOG_FILE_TIME_FORMAT = "yyyy-MM-dd_HHmmss";

    private final ConfigService configService;

    @Autowired
    public LogService(ConfigService configService) {
        this.configService = configService;
    }

    public File createSqlLogFile() {
        File logFile = this.createLogFile(SqlConfig.SQL_EXECUTION_LOG_FILE_PREFIX, SqlConfig.startTimestamp);
        return logFile;
    }

    public File createScriptLogFile() {
        return this.createLogFile(ScriptConfig.SCRIPT_EXECUTION_LOG_FILE_PREFIX, new Date());
    }

    private File createLogFile(String prefix, Date timestamp) {
        File folderLog = new File(configService.findAppRelevantPathByFolderName(Config.LOG_FOLDER));
        String filenameLog = prefix + DateFormatUtils.format(timestamp, LOG_FILE_TIME_FORMAT) + LOG_EXTENSION;
        File file = new File(folderLog.getAbsolutePath() + File.separator + filenameLog);
        file.getParentFile().mkdirs();
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }

    private void log(File logFile, String content) {
        try {
            FileUtils.writeStringToFile(logFile, content,
                    StandardCharsets.UTF_8, true);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public void logSqlExecution(String content) {
        log(SqlConfig.sqlExecutionLogFile,
                content + System.getProperty("line.separator"));
    }

    public void logScriptExecution(String content) {
        log(ScriptConfig.scriptExecutionLogFile, content);
    }

    public void logScriptExecutionLine(String content) {
        log(ScriptConfig.scriptExecutionLogFile,
                content + System.getProperty("line.separator"));
    }
}

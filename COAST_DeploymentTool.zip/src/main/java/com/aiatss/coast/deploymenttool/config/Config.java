package com.aiatss.coast.deploymenttool.config;

public class Config {

    /**
     * Application static configuration
     */
    public static final String DOMAIN = "AIA";

    /**
     * This class contains constant key in table TblConfig
     */
    public static final String PT_PARENT_FOLDER = "PT_PARENT_FOLDER";

    public static final String LOG_FOLDER = "LOG_FOLDER";

    public static final String SCRIPT_FOLDER = "SCRIPT_FOLDER";

    public static final String SQL_EXECUTION = "SQL_EXECUTION";

    public static final String SQL_PATH_PREFIX = "SQL_PATH_PREFIX";

    public static final String DB_FOLDER_PREFIX_ = "DB_FOLDER_PREFIX_";

    public static final String LAN_USERNAME = "LAN_USERNAME";

    public static final String LAN_PASSWORD = "LAN_PASSWORD";

    public static final String LDAP_GROUP = "LDAP_GROUP";

    public static final String DEFAULT_ASSIGNEE = "DEFAULT_ASSIGNEE";

    public static final String ENV = "ENV";

    public static final String _STATUS = "_STATUS";

    public static final String UAT_STATUS = "UAT_STATUS";

    public static final String PROD_STATUS = "PROD_STATUS";

    public static final String JIRA_DEFAULT_INIT_STATUS_KEY = "JIRA_DEFAULT_INIT_STATUS_KEY";

    public static final String JIRA_LIST_PATH = "JIRA_LIST_PATH";//COAST_JIRA_REGEX

    public static final String COAST_JIRA_REGEX = "COAST_JIRA_REGEX";
}

package com.aiatss.coast.deploymenttool.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.sql.DataSource;
import java.sql.*;

@Controller
@RequestMapping(value = "/test")
public class TestController {

    private final DataSource dataSource;

    @Autowired
    public TestController(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @RequestMapping("/execute")
    @ResponseBody
    public String execute(String sql) {
        StringBuilder respBuilder = new StringBuilder();
        try {
            Connection connection = null;
            connection = dataSource.getConnection();

            int spId = this.showConnSPID(connection);
            respBuilder.append("Session ID: " + spId + "\n");

            Statement statement = connection.createStatement();
            statement.execute(sql);
            SQLWarning warnings = statement.getWarnings();
            while (warnings != null) {
                respBuilder.append("[Session ").append(spId).append("] ").append(warnings.getMessage()).append("\n");
                warnings = warnings.getNextWarning();
            }
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            respBuilder.append(e.getStackTrace().toString());
        }
        return respBuilder.toString();
    }

    private int showConnSPID(Connection conn) throws SQLException {
        int spId = 0;
        Statement stmt = conn.createStatement();
        stmt.execute("SELECT @@SPID");
        ResultSet rs = stmt.getResultSet();
        if (rs != null) {
            while (rs.next()) {
                spId = rs.getInt(1);
            }
        }
        return spId;
    }
}

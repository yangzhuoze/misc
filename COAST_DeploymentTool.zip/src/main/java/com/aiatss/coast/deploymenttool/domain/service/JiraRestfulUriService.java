package com.aiatss.coast.deploymenttool.domain.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.aiatss.coast.deploymenttool.bean.jira.Assignee;
import com.aiatss.coast.deploymenttool.bean.jira.Authorization;
import com.aiatss.coast.deploymenttool.bean.jira.JIRA;
import com.aiatss.coast.deploymenttool.bean.jira.Reporter;
import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.config.JiraConfig;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.JiraRestfulUri;
import com.aiatss.coast.deploymenttool.infrastructure.repository.JiraRestfulUriRepository;
import com.aiatss.coast.deploymenttool.util.HttpUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
@Service
public class JiraRestfulUriService {

    private final JiraRestfulUriRepository jiraRestfulUriRepository;

    private final ConfigService configService;

    private static final Logger LOGGER = LoggerFactory.getLogger(JiraRestfulUriService.class);

    //initial authorization used for jira Basic authorization
    private final Authorization auth;

    //initial default jira(production issue) status map
    private final Map<String, String> statusMap;

    private final String ENV;

    @Autowired
    public JiraRestfulUriService(JiraRestfulUriRepository jiraRestfulUriRepository, ConfigService configService) {
        this.jiraRestfulUriRepository = jiraRestfulUriRepository;
        this.configService = configService;
        this.auth = new Authorization(configService.retrieveConfigValueByKey(Config.LAN_USERNAME),
                configService.retrieveConfigValueByKey(Config.LAN_PASSWORD));
        this.statusMap = initJiraStatusMap(configService.retrieveConfigValueByKey(Config.JIRA_DEFAULT_INIT_STATUS_KEY));
        this.ENV = configService.retrieveConfigValueByKey(Config.ENV);
    }

    /**
     * 
     * {start update assignee and status for configured env}
     * @param filePath
     * @author Steve-ZW.ChenDC@aia.com
     */
    public void startUpdate(String filePath) {
        if (StringUtils.equalsIgnoreCase(ENV, JiraConfig.ENV_UAT)) {
            updateJiraForUAT(filePath);
        }
        else if (StringUtils.equalsIgnoreCase(ENV, JiraConfig.ENV_PROD)) {
            updateJiraForPROD(filePath);
        }
        else {
            LOGGER.error(ENV + " don't exist in " + JiraConfig.ENV_UAT + " or " + JiraConfig.ENV_PROD);
        }
    }

    /**
     * 
     * {get jira list file}
     * @param filePath
     * @return
     * @author Steve-ZW.ChenDC@aia.com
     */
    public File getJiraFile(String filePath) {
        File jiraFile = new File(filePath);
        if (!jiraFile.exists()) {
            LOGGER.warn("File don't exist " + filePath + "start create a new empty file.");
            try {
                jiraFile.createNewFile();
            }
            catch (IOException e) {
                LOGGER.error("create a empty file failed!");
                e.printStackTrace();
            }
        }
        return jiraFile;
    }

    /**
     * 
     * {update uat env jira status}
     * @param filePath
     * @author Steve-ZW.ChenDC@aia.com
     */
    public void updateJiraForUAT(String filePath) {
        for (final String key : getFileContentListByNewLine(getJiraFile(filePath))) {
            changeAssignee(key);
            changeStatus(key);
        }
    }

    /**
     * 
     * {update production env jira status}
     * @param filePath
     * @author Steve-ZW.ChenDC@aia.com
     */
    public void updateJiraForPROD(String filePath) {
        for (final String key : getFileContentListByNewLine(getJiraFile(filePath))) {
            changeStatus(key);
        }
    }

    /**
     * 
     * {get jira restful uri by their functions defined in DB}
     * @param functions
     * @param key
     * @return
     * @author Steve-ZW.ChenDC@aia.com
     */
    public URI getRestfulUriByFunctions(String functions, String key) {
        JiraRestfulUri jiraRestfulUri = jiraRestfulUriRepository.findByFunctions(functions);
        String url = StringUtils.defaultString(jiraRestfulUri.getPrefix()) + key
                + StringUtils.defaultString(jiraRestfulUri.getSuffix());
        URI uri = null;
        try {
            uri = new URI(url);
        }
        catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            LOGGER.error(e.getMessage());
        }
        return uri;
    }

    /**
     * 
     * {get post params by functions,default replace ##}
     * @param functions
     * @param param
     * @return
     * @author Steve-ZW.ChenDC@aia.com
     */
    public String getPostParams(String functions, String param) {
        JiraRestfulUri uri = jiraRestfulUriRepository.findByFunctions(functions);
        return uri.getParams().replace("##", param);
    }

    /**
     * 
     * {initial jira transitions map,mapped status name, id}
     * @param key
     * @return
     * @author Steve-ZW.ChenDC@aia.com
     */
    public Map<String, String> initJiraStatusMap(String key) {
        URI uri = getRestfulUriByFunctions(JiraConfig.GET_JIRA_TRANSITIONSINFO, key);
        String issueContent = HttpUtil.responseBody(uri, HttpMethod.GET, auth);
        Map<String, String> map = new HashMap<String, String>();
        ObjectMapper mapper = new ObjectMapper();
        try {
            JsonNode node = mapper.readTree(issueContent);
            Iterator<JsonNode> it = node.get(JiraConfig.TRANSITIONS).iterator();
            while (it.hasNext()) {
                JsonNode childNode = it.next();
                map.put(childNode.get(JiraConfig.NAME).textValue(), childNode.get(JiraConfig.ID).textValue());
            }
        }
        catch (IOException e) {
            // TODO Auto-generated catch block   
            LOGGER.error(e.getMessage());
        }
        return map;
    }

    /**
     * 
     * {initial jira info}
     * @param key
     * @return
     * @throws Exception
     * @author Steve-ZW.ChenDC@aia.com
     */
    public JIRA initJIRA(String content) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode node = objectMapper.readTree(content);
        String jiraAssignee = null;
        try {
            jiraAssignee = node.get(JiraConfig.FIELDS).get(JiraConfig.ASSIGNEE).get(JiraConfig.NAME).textValue();
        }
        catch (NullPointerException e) {
            LOGGER.error("assignee is null!");
            return null;
        }
        //reporter should not be null
        String jiraReporter = node.get(JiraConfig.FIELDS).get(JiraConfig.REPORTER).get(JiraConfig.NAME).textValue();
        Assignee assignee = new Assignee(jiraAssignee, node.get(JiraConfig.FIELDS).get(JiraConfig.ASSIGNEE)
                .get(JiraConfig.DISPLAY_NAME).textValue());
        Reporter reporter = new Reporter(jiraReporter, node.get(JiraConfig.FIELDS).get(JiraConfig.REPORTER)
                .get(JiraConfig.DISPLAY_NAME).textValue());
        JIRA jira = new JIRA(assignee, reporter, node.get(JiraConfig.FIELDS).get(JiraConfig.STATUS)
                .get(JiraConfig.NAME).textValue(), node.get(JiraConfig.FIELDS).get(JiraConfig.ISSUE_TYPE)
                .get(JiraConfig.NAME).textValue());
        return jira;
    }

    /**
     * 
     * {get issueInfo}
     * @param key
     * @return
     * @author Steve-ZW.ChenDC@aia.com
     */
    public String getJiraInfo(String key) {
        URI uri = getRestfulUriByFunctions(JiraConfig.GET_JIRA_INFO, key);
        return HttpUtil.responseBody(uri, HttpMethod.GET, auth);
    }

    /**
     * 
     * {get issue assignee by reporter ,if reporter contains "-" then set default assignee else set reporter}
     * @param key
     * @return
     * @throws Exception
     * @author Steve-ZW.ChenDC@aia.com
     */
    public String getAssignee(String key) throws Exception {
        JIRA jira = initJIRA(getJiraInfo(key));
        String reporterDisplayName = jira.getReporter().getDisplayName();
        String defaultAssignee = configService.retrieveConfigValueByKey(Config.DEFAULT_ASSIGNEE);
        String assignee = reporterDisplayName.contains("-") ? defaultAssignee : jira.getReporter().getName();
        return assignee;
    }

    /**
     * 
     * {get jira list by read text file}
     * @param file
     * @return
     * @author Steve-ZW.ChenDC@aia.com
     */
    public List<String> getFileContentListByNewLine(File file) {
        List<String> list = new ArrayList<String>();
        try (FileReader stream = new FileReader(file); BufferedReader reader = new BufferedReader(stream)) {
            String str = "";
            while ((str = reader.readLine()) != null) {
                if (str.matches(configService.retrieveConfigValueByKey(Config.COAST_JIRA_REGEX))) {
                    list.add(str.trim());
                }
            }
        }
        catch (IOException e) {
            LOGGER.error(e.getMessage());
        }
        return list;
    }

    /**
     * 
     * {change jira status in each env ,uat->UAT-TODO production->CLOSED}
     * @param key
     * @author Steve-ZW.ChenDC@aia.com
     */
    public void changeStatus(String key) {
        try {
            String envStatus = configService.retrieveConfigValueByKey(Config.ENV) + Config._STATUS;
            String id = "";
            try {
                id = statusMap.get(configService.retrieveConfigValueByKey(envStatus));
            }
            catch (NullPointerException e) {
                LOGGER.error(key + "is not a production issue due to can't find status" + envStatus
                        + " please modify it in the database and retry!");
            }
            String params = getPostParams(JiraConfig.CHANGE_STATUS, id);
            String url = getRestfulUriByFunctions(JiraConfig.CHANGE_STATUS, key).toString();
            HttpUtil.post(url, params, auth);
        }
        catch (Exception e) {
            LOGGER.error("Change " + key + "Status failed,please check!");
        }
    }

    /**
     * 
     * {change jira assignee}
     * @param key
     * @author Steve-ZW.ChenDC@aia.com
     */
    public void changeAssignee(String key) {
        try {
            //String defaultAssignee = configService.retrieveConfigValueByKey(Config.DEFAULT_ASSIGNEE);
            String url = getRestfulUriByFunctions(JiraConfig.CHANGE_ASSIGNEE, key).toString();
            String params = getPostParams(JiraConfig.CHANGE_ASSIGNEE, getAssignee(key));
            HttpUtil.put(url, params, auth);
        }
        catch (Exception e) {
            LOGGER.error("Change " + key + " assignee failed,please check!");
        }
    }

}

package com.aiatss.coast.deploymenttool.application.controller;

import com.aiatss.coast.deploymenttool.bean.view.ResponseBean;
import com.aiatss.coast.deploymenttool.bean.view.SqlViewBean;
import com.aiatss.coast.deploymenttool.domain.service.SqlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/sql")
public class SqlController {

    private final SqlService sqlService;

    @Autowired
    public SqlController(SqlService sqlService) {
        this.sqlService = sqlService;
    }

    @RequestMapping(value = "/load")
    @ResponseBody
    public ResponseBean load() {
        sqlService.load();
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/refresh")
    @ResponseBody
    public ResponseBean refresh() {
        SqlViewBean sqlViewBean = SqlViewBean.buildSQLViewBean();
        return ResponseBean.buildSuccessResponseBean(sqlViewBean);
    }

    @RequestMapping(value = "/descript")
    @ResponseBody
    public ResponseBean descript(@RequestParam String system, @RequestParam String no) {
        String sqlContent = sqlService.descript(system, no);
        return ResponseBean.buildSuccessResponseBean(sqlContent);
    }

    @RequestMapping(value = "/run")
    @ResponseBody
    public ResponseBean run() {
        sqlService.execute();
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/stop")
    @ResponseBody
    public ResponseBean stop() {
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/log")
    @ResponseBody
    public ResponseBean log() {
        return ResponseBean.buildEmptySuccessResponseBean();
    }

}

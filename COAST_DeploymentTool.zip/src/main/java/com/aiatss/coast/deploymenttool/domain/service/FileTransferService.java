package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.FileTransfer;
import com.aiatss.coast.deploymenttool.infrastructure.repository.FileTransferRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FileTransferService {

    private final FileTransferRepository fileTransferRepository;

    @Autowired
    public FileTransferService(FileTransferRepository fileTransferRepository) {
        this.fileTransferRepository = fileTransferRepository;
    }

    public FileTransfer findById(int id) {
        return fileTransferRepository.findOne(id);
    }
}

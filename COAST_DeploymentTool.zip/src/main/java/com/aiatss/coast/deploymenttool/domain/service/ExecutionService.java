package com.aiatss.coast.deploymenttool.domain.service;

public interface ExecutionService {

    public void createExecution(String fileLog);

    public void endExecution();

}

package com.aiatss.coast.deploymenttool.bean.view;

import com.aiatss.coast.deploymenttool.bean.SqlTask;
import com.aiatss.coast.deploymenttool.config.SqlConfig;
import org.apache.commons.io.FileUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class SqlViewBean {

    private boolean btnLog = false;

    private boolean btnLoad = false;

    private boolean btnRun = false;

    private boolean btnStop = false;

    private Date timeStart = SqlConfig.startTimestamp;

    private Date timeEnd = SqlConfig.endTimestamp;

    private Map<String, List<SqlTask>> SQLTaskList;

    private String log;

    public boolean isBtnLog() {
        return btnLog;
    }

    public void setBtnLog(boolean btnLog) {
        this.btnLog = btnLog;
    }

    public boolean isBtnLoad() {
        return btnLoad;
    }

    public void setBtnLoad(boolean btnLoad) {
        this.btnLoad = btnLoad;
    }

    public boolean isBtnRun() {
        return btnRun;
    }

    public void setBtnRun(boolean btnRun) {
        this.btnRun = btnRun;
    }

    public boolean isBtnStop() {
        return btnStop;
    }

    public void setBtnStop(boolean btnStop) {
        this.btnStop = btnStop;
    }

    public Date getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(Date timeStart) {
        this.timeStart = timeStart;
    }

    public Date getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(Date timeEnd) {
        this.timeEnd = timeEnd;
    }

    public Map<String, List<SqlTask>> getSQLTaskList() {
        return SQLTaskList;
    }

    public void setSQLTaskList(Map<String, List<SqlTask>> SQLTaskList) {
        this.SQLTaskList = SQLTaskList;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public static SqlViewBean buildSQLViewBean() {
        SqlViewBean sqlViewBean = new SqlViewBean();
        sqlViewBean.setSQLTaskList(SqlConfig.sqlTaskList);
        try {
            sqlViewBean.setLog(SqlConfig.sqlExecutionLogFile == null ?
                    null : FileUtils.readFileToString(SqlConfig.sqlExecutionLogFile, StandardCharsets.UTF_8));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sqlViewBean;
    }

}

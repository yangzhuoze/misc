package com.aiatss.coast.deploymenttool.application.controller;

import com.aiatss.coast.deploymenttool.bean.view.ResponseBean;
import com.aiatss.coast.deploymenttool.bean.view.ScriptViewBean;
import com.aiatss.coast.deploymenttool.domain.service.ScriptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/script")
public class ScriptController {

    private final ScriptService scriptService;

    @Autowired
    public ScriptController(ScriptService scriptService) {
        this.scriptService = scriptService;
    }

    @RequestMapping(value = "/refresh")
    @ResponseBody
    public ResponseBean refresh() {
        return ResponseBean.buildSuccessResponseBean(new ScriptViewBean());
    }

    @RequestMapping(value = "/load")
    @ResponseBody
    public ResponseBean load() {
        scriptService.load();
        return ResponseBean.buildEmptySuccessResponseBean();
    }

    @RequestMapping(value = "/execute")
    @ResponseBody
    public ResponseBean execute(String[] idList) {
        scriptService.execute(idList);
        return ResponseBean.buildEmptySuccessResponseBean();
    }

}

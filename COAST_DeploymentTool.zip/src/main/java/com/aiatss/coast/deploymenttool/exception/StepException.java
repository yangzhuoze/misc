package com.aiatss.coast.deploymenttool.exception;

public class StepException extends RuntimeException {

    private String errMessage;

    public StepException(String errMessage, Object... args) {
        super(String.format(errMessage, args));
    }

    public StepException(Throwable cause) {
        super(cause);
    }
}

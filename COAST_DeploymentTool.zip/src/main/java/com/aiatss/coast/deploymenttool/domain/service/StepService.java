package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.FileTransfer;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.ShellExecute;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.StepDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StepService {

    private final FileTransferService fileTransferService;

    private final ShellExecuteService shellExecuteService;

    @Autowired
    public StepService(FileTransferService fileTransferService, ShellExecuteService shellExecuteService) {
        this.fileTransferService = fileTransferService;
        this.shellExecuteService = shellExecuteService;
    }

    public void setupCfgObject(List<StepDefinition> stepDefinitions) {
        for (StepDefinition stepDefinition : stepDefinitions) {
            if ("fileTransferStep".equals(stepDefinition.getBean())) {
                FileTransfer fileTransfer = fileTransferService.findById(stepDefinition.getConfig());
                stepDefinition.setCfgObject(fileTransfer);
            } else if ("shellExecuteStep".equals(stepDefinition.getBean())) {
                ShellExecute shellExecute = shellExecuteService.findById(stepDefinition.getConfig());
                stepDefinition.setCfgObject(shellExecute);
            }
        }
    }
}

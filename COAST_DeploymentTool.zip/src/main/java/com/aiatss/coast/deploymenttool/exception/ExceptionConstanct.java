package com.aiatss.coast.deploymenttool.exception;

import java.util.HashMap;
import java.util.Map;

public class ExceptionConstanct {

    public static final Map<String, String> CODE_MAP = new HashMap<>();

    public static final String ERROR_DATA_NOT_EXIST = "CNE1001";
    public static final String ERROR_DATA_IS_EXIST = "CNE1002";

    static {
        CODE_MAP.put(ERROR_DATA_NOT_EXIST, "Data not found: {}");
        CODE_MAP.put(ERROR_DATA_IS_EXIST, "Data already exists: {}");
    }

}

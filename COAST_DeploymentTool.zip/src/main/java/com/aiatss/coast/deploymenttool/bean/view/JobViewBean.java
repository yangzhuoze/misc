package com.aiatss.coast.deploymenttool.bean.view;

import com.aiatss.coast.deploymenttool.config.JobConfig;
import org.apache.commons.io.FileUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class JobViewBean {

    private boolean isRunning;

    private String runResult;

    private String log;

    private String logDetail;

    private Object parameter;

    public boolean isRunning() {
        return isRunning;
    }

    public void setRunning(boolean running) {
        isRunning = running;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public String getLogDetail() {
        return logDetail;
    }

    public void setLogDetail(String logDetail) {
        this.logDetail = logDetail;
    }

    public String getRunResult() {
        return runResult;
    }

    public void setRunResult(String runResult) {
        this.runResult = runResult;
    }

    public Object getParameter() {
        return parameter;
    }

    public void setParameter(Object parameter) {
        this.parameter = parameter;
    }

    public static JobViewBean buildJobViewBean() {
        JobViewBean jobStatus = new JobViewBean();
        jobStatus.setRunning(JobConfig.isJobRunning);
        jobStatus.setRunResult(JobConfig.executionResult);
        jobStatus.setParameter(JobConfig.executionParameter);
        jobStatus.setLog(JobConfig.logContent.toString());
        try {
            if (JobConfig.isShowDetailLog) {
                String logContent = JobConfig.jobDetailLogFile == null ? null :
                        FileUtils.readFileToString(JobConfig.jobDetailLogFile, StandardCharsets.UTF_8);
                jobStatus.setLogDetail(logContent);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return jobStatus;
    }
}

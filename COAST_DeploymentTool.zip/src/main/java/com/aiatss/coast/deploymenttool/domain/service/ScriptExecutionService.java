package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.config.ScriptConfig;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.ScriptExecution;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.User;
import com.aiatss.coast.deploymenttool.infrastructure.repository.ScriptExecutionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class ScriptExecutionService implements ExecutionService {

    private final ScriptExecutionRepository scriptExecutionRepository;

    private final UserService userService;

    @Autowired
    public ScriptExecutionService(ScriptExecutionRepository scriptExecutionRepository, UserService userService) {
        this.scriptExecutionRepository = scriptExecutionRepository;
        this.userService = userService;
    }

    @Override
    public void createExecution(String fileLog) {
        User user = userService.getScriptConfigUser();

        ScriptExecution execution = new ScriptExecution();
        execution.setUser(user);
        execution.setStartTime(ScriptConfig.startTimestamp);
        execution.setLogFile(fileLog);
        scriptExecutionRepository.save(execution);
        ScriptConfig.scriptExecutionId = execution.getId();
    }

    @Override
    public void endExecution() {
        ScriptExecution execution = scriptExecutionRepository.findOne(ScriptConfig.scriptExecutionId);
        execution.setEndTime(new Date());
        execution.setResult(ScriptConfig.scriptExecutionStatus);
        scriptExecutionRepository.save(execution);
    }

}

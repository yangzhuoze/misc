package com.aiatss.coast.deploymenttool.infrastructure.persistence;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
@Entity
@Table(name = "DtTblJiraRestfulUri")
public class JiraRestfulUri {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String functions;

    private String prefix;

    private String suffix;

    private String params;

    private String description;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFunctions() {
        return functions;
    }

    public void setFunctions(String functions) {
        this.functions = functions;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    @Override
    public String toString() {
        return "JiraRestfulUri [id=" + id + ", functions=" + functions + ", prefix=" + prefix + ", suffix=" + suffix
                + ", params=" + params + ", description=" + description + "]";
    }

}

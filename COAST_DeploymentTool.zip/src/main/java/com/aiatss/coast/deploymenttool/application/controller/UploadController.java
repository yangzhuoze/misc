package com.aiatss.coast.deploymenttool.application.controller;

import com.aiatss.coast.deploymenttool.config.HttpConfig;
import com.aiatss.coast.deploymenttool.domain.service.UploadService;
import com.aiatss.coast.deploymenttool.bean.view.ResponseBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
@RequestMapping(value = "upload")
public class UploadController {

    private final UploadService uploadService;

    @Autowired
    public UploadController(UploadService uploadService) {
        this.uploadService = uploadService;
    }

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public ResponseBean retrievePath() {
        return ResponseBean.buildSuccessResponseBean(uploadService.retrieveUploadConfig());
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public ResponseBean submitUpload(@RequestParam("files") List<MultipartFile> files, @RequestParam("upload-type") String type,
                                     @RequestParam("upload-path") String path) {
        System.out.println("Upload Type: " + type);
        System.out.println("Upload path: " + path);
        for (MultipartFile file : files) {
            try {
                uploadService.uploadFile(file, path);
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseBean.buildResponseBean(HttpConfig.SUCCESS_CODE, HttpConfig.ERROR_MESSAGE,
                        e.getMessage());
            }
        }
        return ResponseBean.buildEmptySuccessResponseBean();
    }

}

package com.aiatss.coast.deploymenttool;

import java.util.Date;

public class App {

    public static void main(String[] args) throws Exception {
        System.out.println(new Date(System.currentTimeMillis()));
    }
}

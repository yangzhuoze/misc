package com.aiatss.coast.deploymenttool.util;

public class URLUtils {

    public static String URLBuilder(String protocol, String host, int port) {
        return String.format("%s://%s:%d", protocol, host, port);
    }

    public static String URLBuilder(String protocol, String host, int port, String path) {
        return String.format("%s://%s:%d%s", protocol, host, port, path);
    }

    public static String URLBuilder(String protocol, String host, int port, String user, String password) {
        return String.format("%s://%s:%s@%s:%d", protocol, user, password, host, port);
    }

    public static String URLBuilder(String protocol, String host, int port, String user, String password, String path) {
        return String.format("%s://%s:%s@%s:%d%s", protocol, user, password, host, port, path);
    }

    public static String formatDirectory(String url) {
        url = url.replace("\\", "/");
        if (url.endsWith("/")) {
            return url;
        } else {
            return url + "/";
        }
    }

}

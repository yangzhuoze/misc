package com.aiatss.coast.deploymenttool.config;

import com.aiatss.coast.deploymenttool.bean.SqlTask;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class store static object for sql while running
 */
public class SqlConfig {

    /**
     * Overall running status
      */
    public static final String SQL_STATUS_READY = "READY";
    public static final String SQL_STATUS_RUNNING = "RUNNING";
    public static final String SQL_STATUS_STOPPED = "STOPPED";
    public static final String SQL_STATUS_SUCCESS = "SUCCESS";
    public static final String SQL_STATUS_FAILED = "FAILED";

    /**
     * Single SQL task status
     */
    public static final String SQL_EXECUTE_RESULT_PENDING = "PENDING";
    public static final String SQL_EXECUTE_RESULT_RUNNING = "RUNNING";
    public static final String SQL_EXECUTE_RESULT_SUCCESS = "SUCCESS";
    public static final String SQL_EXECUTE_RESULT_FAILED = "FAILED";
    public static final String SQL_EXECUTE_RESULT_STOPPED = "STOPPED";

    public static final String SQL_EXECUTION_LOG_FILE_PREFIX = "sql-execution_";

    /**
     * Static variable
     */
    public static final Object sqlLock = new Object();
    public static Map<String, List<SqlTask>> sqlTaskList = new HashMap<>();
    public static Thread sqlExecutorThread;

    public static String sqlExecutionUsercode;
    public static String sqlExecutionStatus;
    public static Integer sqlExecutionId = 0;
    public static File sqlExecutionLogFile = null;

    public static Date startTimestamp = new Date(0L);
    public static Date endTimestamp = new Date(0L);

}

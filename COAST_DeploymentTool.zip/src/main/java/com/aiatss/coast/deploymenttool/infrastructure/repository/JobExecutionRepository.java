package com.aiatss.coast.deploymenttool.infrastructure.repository;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.JobExecution;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobExecutionRepository extends JpaRepository<JobExecution, Integer> {

    public List<JobExecution> findAllByRerunIdentifier(String identifier);

}

package com.aiatss.coast.deploymenttool.util;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.aiatss.coast.deploymenttool.bean.jira.Authorization;

/** 
 * <b>Application describing:Http request or post Util</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
public class HttpUtil {
    private static final RestTemplate REST = new RestTemplate();

    public static String responseBody(URI uri, HttpMethod method, Authorization auth) {
        HttpEntity<Map<String, String>> entity = new HttpEntity<Map<String, String>>(constructHearder(auth));
        ResponseEntity<String> response = REST.exchange(uri, method, entity, String.class);
        return response.getBody();
    }

    public static Integer post(String url, Map<?, ?> param, Authorization auth) {
        HttpEntity<Map<?, ?>> entity = new HttpEntity<Map<?, ?>>((Map<?, ?>) param, constructHearder(auth));
        return REST.postForEntity(url, entity, String.class).getStatusCode().value();
    }

    public static Integer post(String url, Object param, Authorization auth) {
        HttpEntity<Object> entity = new HttpEntity<Object>(param, constructHearder(auth));
        ResponseEntity<String> response = REST.postForEntity(url, entity, String.class);
        return response.getStatusCodeValue();
    }

    public static void put(String url, Object param, Authorization auth) {
        HttpEntity<Object> entity = new HttpEntity<Object>(param, constructHearder(auth));
        REST.put(url, entity, param);
    }

    public static MultiValueMap<String, String> constructHearder(Authorization auth) {
        MultiValueMap<String, String> header = new LinkedMultiValueMap<String, String>();
        header.set("Accept", "application/json");
        header.set("Authorization", String.format("Basic %s", getJIRAAuthorization(auth)));
        header.set("Content-Type", "application/json");
        return header;
    }

    public static String getJIRAAuthorization(Authorization auth) {
        String credentials = auth.getUsername() + ":" + auth.getPassword();
        String encoding = "";
        try {
            encoding = new String(jcifs.util.Base64.encode((credentials.getBytes("UTF-8"))));
        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return encoding;
    }
}

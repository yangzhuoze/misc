package com.aiatss.coast.deploymenttool.infrastructure.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "DtTblStep")
public class StepDefinition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "JobId")
    private JobDefinition job;

    @Column(nullable = false)
    private String bean;

    private Integer config;

    private Integer priority;

    @Transient
    private Object cfgObject;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public JobDefinition getJob() {
        return job;
    }

    public void setJob(JobDefinition job) {
        this.job = job;
    }

    public String getBean() {
        return bean;
    }

    public void setBean(String bean) {
        this.bean = bean;
    }

    public Integer getConfig() {
        return config;
    }

    public void setConfig(Integer config) {
        this.config = config;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Object getCfgObject() {
        return cfgObject;
    }

    public void setCfgObject(Object cfgObject) {
        this.cfgObject = cfgObject;
    }
}

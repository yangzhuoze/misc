package com.aiatss.coast.deploymenttool.infrastructure.persistence;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "DtTblJobExecution")
public class JobExecution {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "JobId")
    private JobDefinition job;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "UserId")
    private User user;

    private Date startTime;

    private Date endTime;

    private String result;

    private String rerunIdentifier;

    private String logFile;

    private String parameter;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public JobDefinition getJob() {
        return job;
    }

    public void setJob(JobDefinition job) {
        this.job = job;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getRerunIdentifier() {
        return rerunIdentifier;
    }

    public void setRerunIdentifier(String rerunIdentifier) {
        this.rerunIdentifier = rerunIdentifier;
    }

    public String getLogFile() {
        return logFile;
    }

    public void setLogFile(String logFile) {
        this.logFile = logFile;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }
}

package com.aiatss.coast.deploymenttool.util;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import jcifs.smb.SmbFileOutputStream;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

public class SmbUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger("FileTransferLogger");

    private static final int TRANSFER_BYTE_BUFFER = 5242880;

    public static void upload(String localPath, String remotePath, NtlmPasswordAuthentication auth) throws IOException {
        remotePath = URLUtils.formatDirectory(remotePath);
        File local = new File(localPath);
        if (!local.exists()) {
            throw new IllegalArgumentException("No local file found: " + localPath);
        }

        if (local.isDirectory()) {
            SmbFile remoteDir = new SmbFile(remotePath, auth);
            if (!remoteDir.exists()) {
                remoteDir.mkdirs();
            }
            File[] files = local.listFiles();
            if (files == null || files.length == 0) {
                LOGGER.info("Empty local sub folder: {}", localPath);
                return;
            }

            for (File file : files) {
                if (file.isDirectory()) {
                    upload(file.getAbsolutePath(), remotePath + file.getName(), auth);
                } else {
                    SmbFile remoteFile = new SmbFile(remotePath + file.getName(), auth);
                    SmbFileOutputStream smbOut = new SmbFileOutputStream(remoteFile);
                    long spent = copyFileToOutputStream(file, smbOut);
                    LOGGER.info("Upload file done: {}, spent time: {}", file.getAbsolutePath(), spent);
                }
            }
        } else {
            SmbFile remoteFile = new SmbFile(remotePath + local.getName(), auth);
            SmbFileOutputStream smbOut = new SmbFileOutputStream(remoteFile);
            long spent = copyFileToOutputStream(local, smbOut);
            LOGGER.info("Upload file done: {}, spent time: {}", local.getAbsolutePath(), spent);
        }
    }

    public static void download(String localPath, String remotePath, NtlmPasswordAuthentication auth) throws IOException {
        localPath = URLUtils.formatDirectory(localPath);
        File local = new File(localPath);
        if (!local.exists() || !local.isDirectory()) {
            local.mkdirs();
        } else {
            FileUtils.cleanDirectory(local);
        }
        SmbFile remoteFile = new SmbFile(remotePath, auth);
        if (!remoteFile.exists()) {
            throw new IllegalArgumentException("No remote file found: " + remotePath);
        }

        if (remoteFile.isDirectory()) {
            remotePath = URLUtils.formatDirectory(remotePath);
            SmbFile[] smbFiles = new SmbFile(remotePath, auth).listFiles();
            if (smbFiles == null || smbFiles.length == 0) {
                LOGGER.info("Empty remote sub folder: {}", remotePath);
                return;
            }

            for (SmbFile file : smbFiles) {
                String fileName = file.getName();
                if (file.isDirectory()) {
                    download(localPath + fileName, remotePath + fileName, auth);
                } else {
                    SmbFileInputStream smbIn = new SmbFileInputStream(file);
                    long spent = copyInputStreamToFile(smbIn, new File(localPath + fileName));
                    LOGGER.info("Download file done: {}, spent time: {}", file.getPath(), spent);
                }
            }
        } else {
            SmbFileInputStream smbIn = new SmbFileInputStream(remoteFile);
            long spent = copyInputStreamToFile(smbIn, new File(localPath + remoteFile.getName()));
            LOGGER.info("Download file done: {}, spent time: {}", remoteFile.getPath(), spent);
        }
    }

    private static long copyInputStreamToFile(InputStream is, File file) throws IOException {
        long startTime = System.currentTimeMillis();

        try (BufferedInputStream bis = new BufferedInputStream(is);
             FileOutputStream fos = new FileOutputStream(file)) {
            int n;
            byte[] b = new byte[TRANSFER_BYTE_BUFFER];
            while ((n = bis.read(b)) > 0) {
                fos.write(b, 0, n);
            }
        }

        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }

    private static long copyFileToOutputStream(File file, OutputStream os) throws IOException {
        long startTime = System.currentTimeMillis();

        try (BufferedOutputStream bos = new BufferedOutputStream(os);
             FileInputStream fis = new FileInputStream(file)) {
            int n;
            byte[] b = new byte[TRANSFER_BYTE_BUFFER];
            while ((n = fis.read(b)) > 0) {
                bos.write(b, 0, n);
            }
        }

        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }

}

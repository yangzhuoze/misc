package com.aiatss.coast.deploymenttool.config;

import java.io.File;

public class JobConfig {

    public static final String JOB_LOG_KEY = "jobDatetime";
    public static String jobDetailLogValue;
    public static File jobDetailLogFile;
    public static boolean isShowDetailLog;
    public static StringBuilder logContent = new StringBuilder();

    public static boolean isJobRunning = false;
    public static String executionResult = null;
    public static Object executionParameter = null;
    public static final String RESULT_SUCCESS = "SUCCESS";
    public static final String RESULT_FAILED = "FAILED";

}

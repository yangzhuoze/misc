package com.aiatss.coast.deploymenttool.infrastructure.repository;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.ScriptConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ScriptConfigRepository extends JpaRepository<ScriptConfig, Integer> {

    ScriptConfig findByName(String name);

}

package com.aiatss.coast.deploymenttool.application.step;

import java.util.Map;

import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.aiatss.coast.deploymenttool.config.Config;
import com.aiatss.coast.deploymenttool.domain.service.ConfigService;
import com.aiatss.coast.deploymenttool.domain.service.JiraRestfulUriService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** 
 * <b>Application describing:steps of update jira </b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
@Component
@Scope(value = "prototype")
public class UpdateJiraStep implements Step {

    private final JiraRestfulUriService jiraService;

    private final ConfigService configService;

    @Autowired
    public UpdateJiraStep(JiraRestfulUriService jiraService, ConfigService configService) {
        this.jiraService = jiraService;
        this.configService = configService;
    }

    /**
     * {start to change Jira status and assignee}
     * @param config
     * @param parameter
     * @author Steve-ZW.ChenDC@aia.com
     */

    @Override
    public void execute(int config, Object parameter) {

        String filePath = configService.retrieveConfigValueByKey(Config.JIRA_LIST_PATH);
        if (parameter instanceof ObjectNode) {
            @SuppressWarnings("unchecked")
            //{"pkg_home":"\\cangzdwats01\CoastPackage\20180830\application"}
            Map<String, String> jsonMap = new ObjectMapper().convertValue(parameter, Map.class);
            filePath = StringSubstitutor.replace(filePath, jsonMap);
        }
        System.out.println(filePath);
        jiraService.startUpdate(filePath);
    }
}

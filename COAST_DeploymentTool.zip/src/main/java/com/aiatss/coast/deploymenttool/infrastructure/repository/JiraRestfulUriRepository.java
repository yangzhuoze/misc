package com.aiatss.coast.deploymenttool.infrastructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.JiraRestfulUri;

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
@Repository
public interface JiraRestfulUriRepository extends JpaRepository<JiraRestfulUri, Integer> {

    JiraRestfulUri findByFunctions(String functions);

}

package com.aiatss.coast.deploymenttool.config;

public class HttpConfig {

    // Response Bean
    public static final String SUCCESS_CODE = "200";
    public static final String SUCCESS_MESSAGE = "SUCCESS";
    public static final String ERROR_CODE = "500";
    public static final String ERROR_MESSAGE = "ERROR";

    public static final String SESSION_USER_KEY = "CurrentUser";

}

package com.aiatss.coast.deploymenttool.domain.service;

import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlExecute;
import com.aiatss.coast.deploymenttool.infrastructure.persistence.SqlSequence;
import com.aiatss.coast.deploymenttool.infrastructure.repository.SqlExecuteRepository;
import com.aiatss.coast.deploymenttool.util.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Service
public class SqlExecuteService {

    private final SqlExecuteRepository sqlExecuteRepository;

    private final ConfigService configService;

    @Autowired
    public SqlExecuteService(SqlExecuteRepository sqlExecuteRepository, ConfigService configService) {
        this.sqlExecuteRepository = sqlExecuteRepository;
        this.configService = configService;
    }

    public SqlExecute findById(int id) {
        return sqlExecuteRepository.findOne(id);
    }

    public List<File> getFilesBySequences(SqlExecute execute) {
        List<File> sqlFiles = new ArrayList<>();
        
        for (SqlSequence sequence : execute.getSequences()) {
            List<File> filePathList = FileUtils.getFilesByDirReg(
                    configService.findAppRelevantPathByFolder(execute.getPathPrefix()), sequence.getPath());
            sqlFiles.addAll(filePathList);
        }
        return sqlFiles;
    }
}

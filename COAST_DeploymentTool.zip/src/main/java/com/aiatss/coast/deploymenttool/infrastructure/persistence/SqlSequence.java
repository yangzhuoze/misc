package com.aiatss.coast.deploymenttool.infrastructure.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "DtTblSqlSequence")
public class SqlSequence implements Comparable<SqlSequence> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String path;

    @Column(nullable = false)
    private Integer priority;

    @Column(nullable = false)
    private String system;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "SqlExecuteId")
    private SqlExecute execute;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public SqlExecute getExecute() {
        return execute;
    }

    public void setExecute(SqlExecute execute) {
        this.execute = execute;
    }

    @Override
    public int compareTo(SqlSequence o) {
        return this.priority - o.priority;
    }
}

/** 
 * <b>Application describing:</b> <br>
 * @author Steve-ZW.ChenDC@aia.com
 * @version $Revision$
 */
package com.aiatss.coast.deploymenttool.bean.jira;
BEGIN TRAN

/****** Object:  Table [dbo].[DtTblConfig]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblConfig](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Key] [nvarchar](max) NOT NULL,
	[Value] [nvarchar](max) NOT NULL,
	[System] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblFileTransfer]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblFileTransfer](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[ServerInfoId] [int] NULL,
	[LocalPath] [nvarchar](max) NOT NULL,
	[RemotePath] [nvarchar](max) NOT NULL,
	[Direction] [nvarchar](max) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblFileUpload]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblFileUpload](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Type] [nvarchar](max) NOT NULL,
	[Path] [nvarchar](max) NOT NULL,
	[Description] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblJiraRestfulUri]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblJiraRestfulUri](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[functions] [nvarchar](max) NOT NULL,
	[prefix] [nvarchar](max) NULL,
	[suffix] [nvarchar](max) NULL,
	[params] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblJobExecution]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblJobExecution](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[JobId] [int] NULL,
	[UserId] [int] NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Result] [nvarchar](max) NULL,
	[LogFile] [nvarchar](max) NULL,
	[Parameter] [nvarchar](max) NULL,
	[RerunIdentifier] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblJobMaster]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblJobMaster](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[Description] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblJobParam]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblJobParam](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[JobId] [int] NULL,
	[Tag] [nvarchar](max) NOT NULL,
	[Type] [nvarchar](max) NOT NULL,
	[Key] [nvarchar](max) NOT NULL,
	[Value] [nvarchar](max) NULL,
	[IsHidden] [nchar](1) NULL,
	[IsRerunCriteria] [nchar](1) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblPermission]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblPermission](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PermissionCode] [nvarchar](max) NOT NULL,
	[PermissionName] [nvarchar](max) NOT NULL,
	[PermissionType] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblScriptExecution]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblScriptExecution](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ScriptId] [int] NULL,
	[UserId] [int] NULL,
	[StartTime] [int] NOT NULL,
	[EndTime] [int] NULL,
	[LogFile] [nvarchar](max) NULL,
	[Result] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblServerInfo]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblServerInfo](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[Protocol] [nvarchar](max) NOT NULL,
	[Host] [nvarchar](max) NOT NULL,
	[Port] [int] NULL,
	[Username] [nvarchar](max) NULL,
	[Password] [nvarchar](max) NULL,
	[PubKeyPath] [nvarchar](max) NULL,
	[PassPhrase] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblShellExecute]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblShellExecute](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[ServerInfoId] [int] NOT NULL,
	[Path] [nvarchar](max) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblSqlConnection]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblSqlConnection](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[System] [nvarchar](max) NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[Type] [nvarchar](max) NOT NULL,
	[JNDIName] [nvarchar](max) NULL,
	[Driver] [nvarchar](max) NULL,
	[Url] [nvarchar](max) NULL,
	[Username] [nvarchar](max) NULL,
	[Password] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblSqlExecute]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblSqlExecute](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NULL,
	[ConnectionId] [int] NULL,
	[PathPrefix] [nvarchar](max) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblSqlExecution]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblSqlExecution](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LogFile] [nvarchar](max) NOT NULL,
	[StartTime] [int] NOT NULL,
	[EndTime] [int] NULL,
	[UserId] [int] NULL,
	[Result] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblSqlSequence]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblSqlSequence](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[SqlExecuteId] [int] NULL,
	[Path] [nvarchar](max) NOT NULL,
	[Priority] [int] NOT NULL,
	[System] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblStep]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblStep](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NULL,
	[JobId] [int] NULL,
	[Bean] [nvarchar](max) NOT NULL,
	[Config] [int] NULL,
	[Priority] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblUser]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblUser](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](max) NOT NULL,
	[UserCode] [nvarchar](max) NOT NULL,
	[GivenName] [nvarchar](max) NULL,
	[Email] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NOT NULL,
	[IsAdmin] [nvarchar](max) NOT NULL,
	[LastLoginDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DtTblUserPermission]    Script Date: 10/18/2018 2:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DtTblUserPermission](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NULL,
	[PermissionId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[DtTblJobParam] ADD  DEFAULT ('N') FOR [IsHidden]
GO
ALTER TABLE [dbo].[DtTblJobParam] ADD  DEFAULT ('N') FOR [IsRerunCriteria]
GO
ALTER TABLE [dbo].[DtTblStep] ADD  DEFAULT ((0)) FOR [Priority]
GO
ALTER TABLE [dbo].[DtTblFileTransfer]  WITH CHECK ADD FOREIGN KEY([ServerInfoId])
REFERENCES [dbo].[DtTblServerInfo] ([Id])
GO
ALTER TABLE [dbo].[DtTblJobExecution]  WITH CHECK ADD FOREIGN KEY([JobId])
REFERENCES [dbo].[DtTblJobMaster] ([Id])
GO
ALTER TABLE [dbo].[DtTblJobExecution]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[DtTblUser] ([Id])
GO
ALTER TABLE [dbo].[DtTblJobParam]  WITH CHECK ADD FOREIGN KEY([JobId])
REFERENCES [dbo].[DtTblJobMaster] ([Id])
GO
ALTER TABLE [dbo].[DtTblScriptExecution]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[DtTblUser] ([Id])
GO
ALTER TABLE [dbo].[DtTblShellExecute]  WITH CHECK ADD FOREIGN KEY([ServerInfoId])
REFERENCES [dbo].[DtTblServerInfo] ([Id])
GO
ALTER TABLE [dbo].[DtTblSqlExecute]  WITH CHECK ADD FOREIGN KEY([ConnectionId])
REFERENCES [dbo].[DtTblSqlConnection] ([Id])
GO
ALTER TABLE [dbo].[DtTblSqlExecution]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[DtTblUser] ([Id])
GO
ALTER TABLE [dbo].[DtTblSqlSequence]  WITH CHECK ADD FOREIGN KEY([SqlExecuteId])
REFERENCES [dbo].[DtTblSqlExecute] ([Id])
GO
ALTER TABLE [dbo].[DtTblStep]  WITH CHECK ADD FOREIGN KEY([JobId])
REFERENCES [dbo].[DtTblJobMaster] ([Id])
GO
ALTER TABLE [dbo].[DtTblUserPermission]  WITH CHECK ADD FOREIGN KEY([PermissionId])
REFERENCES [dbo].[DtTblPermission] ([Id])
GO


/*
*	Create database / schema done
*	
*	Start insert initial data
*/


SET IDENTITY_INSERT [dbo].[DtTblJobMaster] ON 

GO
INSERT [dbo].[DtTblJobMaster] ([Id], [Name], [Description]) VALUES (1, N'Deploy COAST', NULL)
GO
SET IDENTITY_INSERT [dbo].[DtTblJobMaster] OFF
GO
SET IDENTITY_INSERT [dbo].[DtTblJobParam] ON 

GO
INSERT [dbo].[DtTblJobParam] ([Id], [JobId], [Tag], [Type], [Key], [Value], [IsHidden], [IsRerunCriteria]) VALUES (1, 1, N'input', N'text', N'pkg_home', N'/CoastPackage/%d{YYYYMMDD}/application', N'N', N'Y')
GO
SET IDENTITY_INSERT [dbo].[DtTblJobParam] OFF
GO
SET IDENTITY_INSERT [dbo].[DtTblStep] ON 

GO
INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (1, N'Download Autosys', 1, N'fileTransferStep', 1, 1)
GO
INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (2, N'Download Template', 1, N'fileTransferStep', 3, 2)
GO
INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (3, N'Upload Autosys', 1, N'fileTransferStep', 2, 3)
GO
INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (4, N'Upload Template', 1, N'fileTransferStep', 4, 4)
GO
INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (5, N'Grant Priviledge for Autosys and Template', 1, N'shellExecuteStep', 1, 5)
GO
INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (6, N'Remove log file', 1, N'shellExecuteStep', 2, 6)
GO
INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (7, N'Remove WAS cache', 1, N'shellExecuteStep', 3, 7)
GO
INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (8, N'Verify result', 1, N'shellExecuteStep', 4, 8)
GO
--INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (9, N'Download UAT1 BE WAR package', 1, N'fileTransferStep', 5, 9)
--GO
--INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (10, N'Upload UAT1 BE WAR package', 1, N'fileTransferStep', 7, 10)
--GO
--INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (11, N'Download UAT1 FE WAR package', 1, N'fileTransferStep', 6, 11)
--GO
--INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (12, N'Upload UAT1 FE WAR package', 1, N'fileTransferStep', 8, 12)
--GO
--INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (13, N'Install BE WAR into WAS', 1, N'shellExecuteStep', 5, 13)
--GO
--INSERT [dbo].[DtTblStep] ([Id], [Name], [JobId], [Bean], [Config], [Priority]) VALUES (14, N'Install FE WAR into WAS', 1, N'shellExecuteStep', 6, 14)
--GO
SET IDENTITY_INSERT [dbo].[DtTblStep] OFF
GO
SET IDENTITY_INSERT [dbo].[DtTblServerInfo] ON 

GO
INSERT [dbo].[DtTblServerInfo] ([Id], [Name], [Protocol], [Host], [Port], [Username], [Password], [PubKeyPath], [PassPhrase]) VALUES (1, N'CoastPackage', N'smb', N'CANGZDWATS01', 445, NULL, NULL, NULL, NULL)
GO

/* TODO:
 * Need Update
 */
INSERT [dbo].[DtTblServerInfo] ([Id], [Name], [Protocol], [Host], [Port], [Username], [Password], [PubKeyPath], [PassPhrase]) VALUES (2, N'UAT02', N'sftp', N'thadculwct02', 22, N'mappct01', NULL, N'/users/mappct01/.ssh/id_rsa', NULL)
GO
INSERT [dbo].[DtTblServerInfo] ([Id], [Name], [Protocol], [Host], [Port], [Username], [Password], [PubKeyPath], [PassPhrase]) VALUES (3, N'UAT02_SSH', N'ssh', N'thadculwct02', 22, N'mappct01', NULL, N'/users/mappct01/.ssh/id_rsa', NULL)
GO

SET IDENTITY_INSERT [dbo].[DtTblServerInfo] OFF
GO
SET IDENTITY_INSERT [dbo].[DtTblFileTransfer] ON 

GO
INSERT [dbo].[DtTblFileTransfer] ([Id], [Name], [ServerInfoId], [LocalPath], [RemotePath], [Direction]) VALUES (1, N'Autosys', 1, N'/tmp/Autosys', N'${pkg_home}/Autosys', N'GET')
GO
INSERT [dbo].[DtTblFileTransfer] ([Id], [Name], [ServerInfoId], [LocalPath], [RemotePath], [Direction]) VALUES (2, N'Autosys', 2, N'/tmp/Autosys', N'/coast/autosys', N'PUT')
GO
INSERT [dbo].[DtTblFileTransfer] ([Id], [Name], [ServerInfoId], [LocalPath], [RemotePath], [Direction]) VALUES (3, N'Template', 1, N'/tmp/Template', N'${pkg_home}/FULL_Template', N'GET')
GO
INSERT [dbo].[DtTblFileTransfer] ([Id], [Name], [ServerInfoId], [LocalPath], [RemotePath], [Direction]) VALUES (4, N'Template', 2, N'/tmp/Template', N'/coast/Template', N'PUT')
GO
--INSERT [dbo].[DtTblFileTransfer] ([Id], [Name], [ServerInfoId], [LocalPath], [RemotePath], [Direction]) VALUES (5, N'Package UAT1 BE', 1, N'/tmp/Package', N'${pkg_home}/thadculwct01/COAST_Web-0.0.1-SNAPSHOT.war', N'GET')
--GO
--INSERT [dbo].[DtTblFileTransfer] ([Id], [Name], [ServerInfoId], [LocalPath], [RemotePath], [Direction]) VALUES (6, N'Package UAT1 BE', 2, N'/tmp/Package', N'/coast/promotion/deploy', N'PUT')
--GO
--INSERT [dbo].[DtTblFileTransfer] ([Id], [Name], [ServerInfoId], [LocalPath], [RemotePath], [Direction]) VALUES (7, N'Package UAT1 FE', 1, N'/tmp/Package', N'${pkg_home}/thadculwct01/COAST_FE_WEB-0.0.1-SNAPSHOT.war', N'GET')
--GO
--INSERT [dbo].[DtTblFileTransfer] ([Id], [Name], [ServerInfoId], [LocalPath], [RemotePath], [Direction]) VALUES (8, N'Package UAT1 FE', 2, N'/tmp/Package', N'/coast/promotion/deploy', N'PUT')
--GO
SET IDENTITY_INSERT [dbo].[DtTblFileTransfer] OFF
GO
SET IDENTITY_INSERT [dbo].[DtTblConfig] ON 

GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (1, N'SQL_EXECUTION_1', N'COAST_BE', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (2, N'SQL_EXECUTION_2', N'COAST_FE', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (3, N'DB_FOLDER_PREFIX_COAST_BE', N'/COAST_DB', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (4, N'DB_FOLDER_PREFIX_COAST_FE', N'/COAST_FE_DB', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (5, N'SQL_PATH_PREFIX', N'/promotion', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (6, N'LOG_FOLDER', N'/logs', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (7, N'PT_PARENT_FOLDER', N'/coast/promotion', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (8, N'SCRIPT_FOLDER', N'/script', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (9, N'LAN_USERNAME', N'cdcoast02', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (10, N'LAN_PASSWORD', N'Steve1234..', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (11, N'LDAP_GROUP', N'CN=TSS-AS-GP-COAST-Release,OU=AIATSS,OU=DistributionGroups,OU=ExchangeMigration,DC=AIA,DC=BIZ', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (12, N'DEFAULT_ASSIGNEE', N'ASNPHLJ', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (13, N'ENV', N'UAT', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (14, N'UAT_STATUS', N'CLOSE', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (15, N'PROD_STATUS', N'Closed', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (16, N'JIRA_LIST', N'/jira-list.txt', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (17, N'JIRA_DEFAULT_INIT_STATUS_KEY', N'GPCPCOAST-34751', NULL)
GO
INSERT [dbo].[DtTblConfig] ([Id], [Key], [Value], [System]) VALUES (18, N'COAST_JIRA_REGEX', N'GPCPCOAST-[0-9]+', NULL)
GO
SET IDENTITY_INSERT [dbo].[DtTblConfig] OFF
GO

SET IDENTITY_INSERT [dbo].[DtTblJiraRestfulUri] ON 

GO
INSERT [dbo].[DtTblJiraRestfulUri] ([id], [functions], [prefix], [suffix], [params], [description]) VALUES (1, N'getJiraInfo', N'http://cangzpwsvn01:8080/rest/api/2/issue/', N'', NULL, N'get Jira item infomations')
GO
INSERT [dbo].[DtTblJiraRestfulUri] ([id], [functions], [prefix], [suffix], [params], [description]) VALUES (2, N'changeAssignee', N'http://cangzpwsvn01:8080/rest/api/2/issue/', N'/assignee', N'{"name":"##"}', N'change Jira assignee')
GO
INSERT [dbo].[DtTblJiraRestfulUri] ([id], [functions], [prefix], [suffix], [params], [description]) VALUES (3, N'changeStatus', N'http://cangzpwsvn01:8080/rest/api/2/issue/', N'/transitions?expand=transitions.fields', N'{"transition":{"id":"##"}}', N'change Jira Status')
GO
INSERT [dbo].[DtTblJiraRestfulUri] ([id], [functions], [prefix], [suffix], [params], [description]) VALUES (4, N'getJiraTransitionsInfo', N'http://cangzpwsvn01:8080/rest/api/2/issue/', N'/transitions?expand=transitions.fields', NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[DtTblJiraRestfulUri] OFF
GO

SET IDENTITY_INSERT [dbo].[DtTblShellExecute] ON 

GO
INSERT [dbo].[DtTblShellExecute] ([Id], [Name], [ServerInfoId], [Path]) VALUES (1, N'Grant Privilege for Autosys and Template', 3, N'/coast/promotion/temp/test.sh')
GO
INSERT [dbo].[DtTblShellExecute] ([Id], [Name], [ServerInfoId], [Path]) VALUES (2, N'Remove log file', 3, N'/coast/promotion/script/log.sh')
GO
INSERT [dbo].[DtTblShellExecute] ([Id], [Name], [ServerInfoId], [Path]) VALUES (3, N'Remove WAS cache', 3, N'/coast/promotion/script/wascache.sh')
GO
INSERT [dbo].[DtTblShellExecute] ([Id], [Name], [ServerInfoId], [Path]) VALUES (4, N'Verify result', 3, N'/coast/promotion/script/verifyresult.sh')
GO
--INSERT [dbo].[DtTblShellExecute] ([Id], [Name], [ServerInfoId], [Path]) VALUES (5, N'Install BE WAR package', 3, N'/coast/promotion/script/deploybe.sh')
--GO
--INSERT [dbo].[DtTblShellExecute] ([Id], [Name], [ServerInfoId], [Path]) VALUES (6, N'Install FE WAR package', 3, N'/coast/promotion/script/deployfe.sh')
--GO
SET IDENTITY_INSERT [dbo].[DtTblShellExecute] OFF
GO


/*
 *
 * Insert initial data done.
 *
 */

--COMMIT
ROLLBACK